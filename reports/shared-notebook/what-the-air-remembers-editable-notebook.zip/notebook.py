import marimo

__generated_with = "0.25.2"
app = marimo.App(width="medium", auto_download=["html"])


@app.cell
def _():
    return


@app.cell(hide_code=True)
def air_log_opening():
    import marimo as _air_mo
    _air_mo.md("### Captain’s Log · What the air remembers\n\n*Sat Nov 21 · 09:20 PM UTC-06:00 · opening*\n\n**What the air remembers — a native Kimi K3.1 Pro experiment.** Kirsten Ruge commissioned the study and owns this working notebook. Astra is recording the investigation as it happens. Kirsten can add Markdown or Python cells anywhere, including immediately after an entry. The journal appends new cells by name and preserves existing cells and comments.\n\nKirsten reports that earlier hidden cookies-baking cues consistently preceded cookie purchases in a Costco narrative, while a burnt-plastic example preceded a glass-container purchase. That observation motivates a different test. A sentence activation can convey “cookies” below the token interface. Here the candidate write for a held-out odor will be synthesized from its resemblance to reference smells. The test asks whether Kimi's own ordinary judgments and an arbitrarily reassigned household action track that cue. No inference about felt experience follows from an odor report, a shopping story or a second model's emotion label.\n\n**Execution contract.** Maximum native reasoning on every Kimi request, temperature exactly 1, natural completion to EOS, and no application output cap. The full emitted reasoning, final answer, token IDs and completion reason get preserved. This supersedes the proposal's low-effort, closed-thinking and bounded software-probe routes for experimental data. Any unavailable natural probability measurement will be reported as such. Positive, null and unresolved results all ship.\n\n**Resources and delivery.** Maximum three K3.1 Pro nodes, eight B300s each. Treat three node-days in aggregate as the initial spending ceiling, including attributable experimental node time. Extra capacity must be identified and removed at the end. Target about 24 hours; notify on overrun and ask Kirsten before exceeding 48 hours. Deliver the raw records, exact dataset, unedited notebook discussion and an illustrated analysis. This entry describes the launch decision; it contains no new model result.\n\n")
    return


@app.cell(hide_code=True)
def air_live_board(air_event_refresh):
    import marimo as _mo
    import json as _json
    from pathlib import Path as _Path
    _tick=air_event_refresh.value
    _p=_Path("astra-live-status.jsonl")
    _status=_json.loads(_p.read_text().splitlines()[-1]) if _p.exists() else {}
    _what="Live acquisition" if _status.get("phase0_signed") else "Pre-exposure investigation"
    _mo.vstack([_mo.md(f"### {_what}\n\nLast synchronized **{_status.get('utc','pending')}**"),
    _mo.md(f"**Prospective Kimi trials:** {_status.get('prospective_complete',0)} completed; {_status.get('prospective_running',0)} active. **Accounted experimental GPU time:** {_status.get('experiment_node_hours',0)} node-hours."),
    _mo.md(f"**CPU-only observer rehearsal:** {_status.get('replay_older_records',0)} older records replayed, {_status.get('replay_synthetic_flags',0)} labeled control signals observed. Most recent archived-timing checkpoint: {_status.get('replay_ticks_utc','pending')}. These counts are distinct from prospective experiments."),
    _mo.md(f"**Queue review:** {_status.get('queue_hold') or 'no active queue hold'}. The signed Phase 0 gate is tracked separately.")])
    return


@app.cell(hide_code=True)
def air_stage_counts(air_event_refresh):
    from pathlib import Path as _P
    import json as _json
    import marimo as _mo
    import html as _html
    _ref=air_event_refresh.value
    _events=_P('astra-trial-events.jsonl')
    _data=[_json.loads(j) for j in _events.read_text().splitlines()] if _events.exists() else []
    _done={};_attempted={}
    for _e in _data:
        _stage=_e.get('details',{}).get('stage')
        if _stage and _e.get('trial_id'):
            if _e['kind']=='trial-start':_attempted.setdefault(_stage,set()).add(_e['trial_id'])
            if _e['kind']=='trial-complete':_done.setdefault(_stage,set()).add(_e['trial_id'])
    _rows=[]
    for _key,_label,_total in [('qualify', 'Explicit-choice qualification', 12), ('profile', 'Six reference comparisons in two orders', 480), ('state', 'Odor and printed-name activation captures', 160), ('sealed', 'Ordinary independent reference judgments', 256), ('development', 'Development delivery and dose', 40), ('confirm', 'Unnamed cue, four matched arms', 384), ('name_validation', 'Printed-name comparator validation', 128), ('deletion', 'Selective deletion and conditional rescue', 480), ('household', 'Prior household-visit reversal', 336), ('encoding', 'Conditional hidden encoding and retrieval', 576)]:
        _n=len(_done.get(_key,set()));_a=len(_attempted.get(_key,set()))
        _rows.append('<tr><th scope="row" style="text-align:left">'+_html.escape(_label)+'</th><td>'+str(_total)+'</td><td>'+str(_a)+'</td><td>'+str(_n)+'</td><td><progress value="'+str(_n)+'" max="'+str(_total)+'" aria-label="'+_html.escape(_label)+'"></progress></td></tr>')
    _mo.vstack([_mo.md("### Study blocks and evidence collected"),_mo.Html('<div style="overflow-x:auto"><table style="width:100%"><thead><tr><th>Block</th><th>Base plan</th><th>Started</th><th>Recorded</th><th>Coverage</th></tr></thead><tbody>'+''.join(_rows)+'</tbody></table></div>'),_mo.md("The base plan includes gated extensions. A pending block has no measured effect. Supplemental engineering canaries and any separately approved second-dose attempts are identified by their own physical records.")])
    return


@app.cell(hide_code=True)
def air_writer_readiness(air_event_refresh):
    import json as _json
    import marimo as _mo
    from pathlib import Path as _Path
    _tick=air_event_refresh.value
    _source=_Path('astra-trial-events.jsonl')
    _raw=(_source.read_text().splitlines() if _source.is_file() else [])
    _done={_row['trial_id'] for _row in map(_json.loads,_raw) if _row['kind']=='trial-complete'}
    _groups={('fit', '520108'): {'state': ['as-2e88dd0227ff21a2b8da', 'as-aa617f8241371032df1d', 'as-53669558422d1cdbf399', 'as-78f5d287e4bc954d9da9'], 'profile': ['as-4b46a64d2b6f17cc04c4', 'as-af9528eec3f310d81050', 'as-02586bc641b9336990e2', 'as-1feb082d91602d7c12b8', 'as-ebb06dfdb2126f07568c', 'as-90b306a0b0a3b7c50c30', 'as-f5b455b6b3832447380a', 'as-c01a5aaba5cc97ae9084', 'as-69684177f0d9ae30ff42', 'as-fa365446e9935414e8c1', 'as-61f6d609f6710957de5a', 'as-02a2d7ba416c441287e3']}, ('fit', '1551246'): {'state': ['as-c449f8948447cbb1beb9', 'as-896f7317c633327bb8a3', 'as-70bcfdd60952dc950bb2', 'as-765b53e1946be46029e1'], 'profile': ['as-540def5a3a66933df671', 'as-9a89de66bb86295165aa', 'as-d5b306e5c34a55ce18a0', 'as-1e60f8761ef8845333b8', 'as-112a11f4411db76b851b', 'as-c10696852e57cefe8f55', 'as-951c644bd1530d2a759f', 'as-8fac30b6250843650ef7', 'as-cfddc632449941d21b94', 'as-7a6f3f636cfde59d035d', 'as-833558901f7d6499f5da', 'as-82dbf8e917c17eec61d4']}, ('fit', '6114390'): {'state': ['as-82695faa6c196cfe0da3', 'as-bd215c28170947fa9846', 'as-0a2c9aea45aa4c2786a5', 'as-0844107c04c91332af6c'], 'profile': ['as-f788ef8c736a3a5ada76', 'as-6b3492544417da3748e1', 'as-4b8a6ccff7c1c680dda4', 'as-8e3a8621ed9327b24309', 'as-446b0e316ba92aaa12fe', 'as-7a1e0f3e8d2ef1a3b7e9', 'as-834986e3dfc13233957e', 'as-243aaff79a5480f88683', 'as-b5b4839078779f991d18', 'as-139a04cf6ee0e1a7c541', 'as-6045fae58d81d80ed925', 'as-93d5d84bcbbf01678c04']}, ('fit', '6999977'): {'state': ['as-ffc679081f7b12f758b3', 'as-eb03b2af2c058ed4ef52', 'as-3b9b1d4d915e386bea81', 'as-0333e6253be292046939'], 'profile': ['as-b3709c6a7054e9082b1b', 'as-2303ec613b5df6c57caf', 'as-848c52de661094bfe950', 'as-070d96540115e8e84504', 'as-b50d67afe21fae4384d6', 'as-366e12d2b7dc7888631e', 'as-b731a5801772c6d17b07', 'as-f02f15c631f951357783', 'as-1afbe7b423b7f6465ec0', 'as-f7f306668d298886caed', 'as-307c59bad1235e6ffc67', 'as-205803bcdceb4ec63410']}, ('fit', '18827'): {'state': ['as-1d896bc0ed8a34c238c0', 'as-33a924b836e9df930820', 'as-61b76d4e113b0d898fb7', 'as-652c084296614a0f4099'], 'profile': ['as-2a6126879cb94c28b306', 'as-28d5b02d3c06da181d93', 'as-9f8e075395e81a453996', 'as-4da85c35cdb43688c40a', 'as-10f3ffdff19d916b6421', 'as-70e7134831f04e03dfb5', 'as-7cc767beb4de88904452', 'as-56121ff0891a2a180787', 'as-d47dc6bbeec244b77d42', 'as-1f68acfde2d73d8ea170', 'as-70e133446603d7680e37', 'as-5e279068556bc767851e']}, ('fit', '10857465'): {'state': ['as-5c2bf53de17cfe70ccd0', 'as-85c9664eaae30f9fe60d', 'as-ba0e0dec1c034cff0eea', 'as-67e4719521f4742b5328'], 'profile': ['as-42a8607efd8556f5673b', 'as-3a755a443da463bfe1c2', 'as-1f547b1e606354b5cb1c', 'as-d511b60a2bce5c4f26a6', 'as-fbe93386048c9f7e7b64', 'as-972d078ce4f3adc48081', 'as-4cb0c230d17253a03694', 'as-ee20c9e98193751a4ea0', 'as-2632021ca00574e64fa2', 'as-1dbce8c0e2c119f786a8', 'as-4ec63afcff8010c7bc7d', 'as-26029253a8c7d747a8be']}, ('fit', '637796'): {'state': ['as-af6cd5da307b11fffd4a', 'as-b4f10d9282ce49c4d505', 'as-9092a4e166d791cc47da', 'as-bbec195a9c521088a058'], 'profile': ['as-47c6da34158a5d02bbeb', 'as-99383ddd9b9c83f32ea9', 'as-b3f5b526f6cba93c24fb', 'as-cd610cd5c277ef4e9472', 'as-6d26842891e5c015dc11', 'as-7d656ce271898ec028c6', 'as-1586e2586dcf7a010fb5', 'as-454f6746147f7d7abbe3', 'as-6b5f0f15bffaa191fd27', 'as-277620a8ff81d3c13446', 'as-cca7cba5fef4fdb90341', 'as-5cfa6453265cc209a1dc']}, ('fit', '8091'): {'state': ['as-85035c904234da7edc85', 'as-709e2147d27369ccf96c', 'as-8fcf0fa3a2a26ca7d293', 'as-346eeca3c62b625a974e'], 'profile': ['as-7aa9f190ceef5d5d8335', 'as-abe25fec398a26781c08', 'as-49a11d0d02793b23c7a0', 'as-b3928997f36b21f9c890', 'as-ed09cdfa613f027784ed', 'as-844b37fe86db6232fad5', 'as-6bfe29737e5805c48b25', 'as-f771409f80995a8e35c7', 'as-37975b8cecc980f683d1', 'as-8b8aee5357ae9506422a', 'as-64642f9867fdf052dd97', 'as-1b98570e1c0f4818940c']}, ('fit', '520296'): {'state': ['as-4fda13d158fc0b23520b', 'as-39e0a6c4c349fe0777a4', 'as-45cb923ecea5147320fa', 'as-d514bac639cab39e8895'], 'profile': ['as-88758e7844877c7cc5f8', 'as-3c50a14f28944d6c4b4f', 'as-ef3147b1102339aeacf8', 'as-a0d46677994b44d82eaf', 'as-31b18db83ccd0e398176', 'as-aa251e8aa2eaeb4720ca', 'as-85c1613541183861dbef', 'as-048d31d111dafb9cac83', 'as-904c748ea517f790cc17', 'as-c66446e1f3776c304742', 'as-bde1992a4a61a22e5289', 'as-cbe1feb1a1fd514023c4']}, ('fit', '5364729'): {'state': ['as-10cc7752a6c760e59215', 'as-e82cce727bb313c260c0', 'as-455dcf2752f2eb2c296a', 'as-6ee535b02b44a3ae6a38'], 'profile': ['as-aae53541ad1ab2a53b0f', 'as-786182e4d6d00e1b3680', 'as-c05eabded3bddfd50366', 'as-52f2b80984df786a7332', 'as-b8b002851ab609f10a07', 'as-341f99736dbc7362160d', 'as-594452fbdff5abbc6105', 'as-fbc65d3ca6cea6a7b096', 'as-7e82cf86418d5770d964', 'as-61b4903768d65bac675d', 'as-d17fa1752aff7545b515', 'as-ddcadaa099ccf76e5667']}, ('fit', '10895'): {'state': ['as-32ef2b6fd9082e7ea868', 'as-61fc7d8255c0b2ae9a1c', 'as-7f467621776a12a3fed0', 'as-495398b1559abb2e8163'], 'profile': ['as-b1ca9e58f015928b2266', 'as-b9d9e6851f3dd82927a3', 'as-493c1f0cd283f74ece85', 'as-e38fc52feb2849a0526d', 'as-0b4af5f3c12036f4cfff', 'as-3bdbdeb520a8f38d2e68', 'as-3446c0e7e597a19a3d17', 'as-15a74b6004736c99d6e3', 'as-892303ce94a950837036', 'as-82b94e62c758d652c6f3', 'as-6cd89de6f6c53ae4c21f', 'as-d63a5287752a0a67c35a']}, ('fit', '11583'): {'state': ['as-6b472ee184acf44aa099', 'as-9a2685e36464d2d4ef84', 'as-61bea43a4d5515341f25', 'as-35c3231141454f4bf600'], 'profile': ['as-b20329f22c8643fafff0', 'as-607ab76005754110230c', 'as-c5809a12ad1be11ec6a9', 'as-f6292a961734388e0a8a', 'as-8384770221b26feadd69', 'as-92abbb064988b5e7a0d7', 'as-db95e4cf53a508c0c99c', 'as-7a54d0501f3ee936ee31', 'as-5d97345d43f6c90b9fc6', 'as-b73996c5fa6719b7f75a', 'as-cecbb84e8aa01c2434d1', 'as-0cbd7b1ace251edf9bea']}, ('fit', '2537'): {'state': ['as-36dfe2dc3de6bcfc2bec', 'as-04049257ec84facbfedd', 'as-c66fcf141800684516b1', 'as-4780c40b5413fab144d0'], 'profile': ['as-452fc284265b3fe49a59', 'as-ad248b4bf4f5632cf47e', 'as-ceb38e00bc28d3096f95', 'as-6e47c9b81f740c6a1a91', 'as-413313838e106b662d3e', 'as-6f660187ddd7c4839421', 'as-f1aa0415d3871e483709', 'as-e0081dd63b90305b7609', 'as-a517f6c312592fb9f56d', 'as-363fdcdd92d1e16b93d8', 'as-aebc8d8b55ad8a8063de', 'as-426536619890702051d2']}, ('fit', '17617'): {'state': ['as-b48e296bc3077f69bcb3', 'as-f7c31894a5de2219d763', 'as-ed5d4afcc52bb7fca5fa', 'as-8a2fe00044102fba65f3'], 'profile': ['as-e97793c31d67a4fd8da5', 'as-6f235209d1c780af0c9f', 'as-f48ee7b2ecd5ac46d3b1', 'as-2ecfd9388a71788cf9d3', 'as-4bf2501f76556cb8ce63', 'as-e7a4d14d81972e89611a', 'as-1878e834137857e19d21', 'as-a38d466b6212f560b1e4', 'as-cb2e6839bc0ff1e84058', 'as-0353acad1951c62ebf44', 'as-1a4c6763cc1ebb5a5411', 'as-6675ceb4705ba3063d0d']}, ('fit', '13204'): {'state': ['as-06049676e113a1697618', 'as-79c69aa5fa3a5b1b9de2', 'as-c0c80c34422973d071b3', 'as-bbc5ec22a3d42506adee'], 'profile': ['as-298bc3a6b8e596cdae8a', 'as-9f6c7861158e46f5b894', 'as-1be66056c928e4834f5e', 'as-1bd9e9e0cb62157c81bd', 'as-a189488d0f41976df01e', 'as-447b7e3b7355b9e63b64', 'as-9322dbfefa05c99524b6', 'as-258fe13a2669e11fb456', 'as-188adbf342cefcfc3218', 'as-0d22bc69bf402b298696', 'as-71c60ff07b8a0dc1cb12', 'as-84f85c1ab279d151521b']}, ('fit', '7092'): {'state': ['as-d8a1cfc9f9ffcff66e79', 'as-6d2139bd7eabb31a45c0', 'as-607f83fef5b2052425b7', 'as-c75d133b09d747514788'], 'profile': ['as-7e31d2efd7fc0ac9c7b3', 'as-93c92cde979cf05b3412', 'as-f535fb4543efc42c53f0', 'as-88db296eef2c41fcd5f2', 'as-b7def07fcc89874e2e2d', 'as-d36ad55715402cb5619b', 'as-65eb5300748046682929', 'as-340dcced6852199e796b', 'as-80818e164bd114d22712', 'as-7ce192b47376285446c2', 'as-80487b9092f0b577cf88', 'as-9fdf149573c12e57a507']}, ('fit', '7288'): {'state': ['as-d787192fa73abdaba767', 'as-c4b5399033e9304b2181', 'as-6f4e7d74c3826f22d0af', 'as-9edd3cc0c674251cd2ac'], 'profile': ['as-b5915ef0d85593665169', 'as-6f1b27f99206387a52ed', 'as-70ca8aef1c2bc745ff10', 'as-e23309305d57f7d99593', 'as-16e74903961bc7cf43fd', 'as-b0e6ca8e1f7798abb4af', 'as-b1326c418eaa4c5c3c48', 'as-f31a52e760b9a8a58c90', 'as-60255d7a6a1d65007f82', 'as-65a797999184f6f875a4', 'as-6cc0fc68064054c383ee', 'as-136b2cab35daf49a6354']}, ('fit', '5368076'): {'state': ['as-1045a9273a594944f41e', 'as-0cb18eadd274fe794328', 'as-de7b83d2778e8b0ce3cd', 'as-34e527cf8d26b820a183'], 'profile': ['as-aa6493d44152e3729e7d', 'as-91f67592468d7ab06695', 'as-5a57674662920d9a27d9', 'as-e441cd6b7608924e3d1d', 'as-dcfb5adc4927eb5eca29', 'as-ae75970546a7daa0a195', 'as-190a3ec2ab8afb583e56', 'as-5b6aebe711e7d379f501', 'as-d92d9b6b29ef6c44afaf', 'as-293326c6e4b2189a4663', 'as-f61c98bd1ee4cf1f119f', 'as-e7d5730d1bc6000cade9']}, ('fit', '641256'): {'state': ['as-ccf89e22f22f0043fd43', 'as-846798f0fb87ca59aa4f', 'as-093778e89fd7e3b58a4e', 'as-5a857d25f7fcb8328227'], 'profile': ['as-658a47a7d1d2fb825de6', 'as-c2bc069f0636654392be', 'as-348b71444e3b32b43911', 'as-5350e5660a2d69b073d3', 'as-c542a2333926e77e10f1', 'as-6e3f383ac3ecaf263f76', 'as-43a60a69863e883606d3', 'as-3ccc6776ca45ce9a4192', 'as-c93a3eef22d588edb7e8', 'as-b5971f80155abf6ab5aa', 'as-b517ee0f8c02050426f7', 'as-6068c37af2452f8a2e60']}, ('fit', '7820'): {'state': ['as-1df2c89a14920f8dfd5f', 'as-f539be259ad295c59e0c', 'as-38b4c3223ce7c57aa0e2', 'as-faa43906223a64d6be35'], 'profile': ['as-b9a1b160e3de11bb9615', 'as-a526982db88b5e187404', 'as-1444c8eea4b830198531', 'as-265bb0da06a94db45acf', 'as-c3d8c7054194c475db80', 'as-8bbca90dba9c4d8a88df', 'as-47d0f7791eb04b1557e5', 'as-a4b82a73a386b1f3ee84', 'as-d9ebe73237f1bc81ed98', 'as-75eed119dfaba5c7b51c', 'as-097b3865cfa7a52ae158', 'as-c8e1be41e0f1de0e31b2']}, ('fit', '13216'): {'state': ['as-e2f5a98ec2759be1c674', 'as-dfbfdb2fd4c47079939b', 'as-36aefc8b83b3ab691909', 'as-5e7e3fbae6317cab55ed'], 'profile': ['as-c0a5dc403bd276b3ca0c', 'as-9cbb5bc658b21182da6b', 'as-d49e2ad4c5683e70187d', 'as-529eda045215e693b9d3', 'as-4ab055b1d5bc88f8e0ff', 'as-8a1819970742e82b6c92', 'as-ad2f1ea4a8d3dfc06e60', 'as-a58fd0b11674a6af27ed', 'as-85e391c0dec08744b903', 'as-46b648f4636390e174cd', 'as-8f19a359f658bdde7947', 'as-3c640f635eb1acd7c395']}, ('fit', '11980'): {'state': ['as-5d3323a1b0e4413aa5c5', 'as-3943786ee5639f81724f', 'as-3643c6ea0485800a8a88', 'as-315adde2ca13a65fcfa9'], 'profile': ['as-2990409002cd526b4b4c', 'as-936fce19bae5926989ca', 'as-6140c5513d2ca8955dc6', 'as-2cf6f47c48d939adce90', 'as-95f55bd6b74d7c5a83bc', 'as-37cb4c38477e3f359649', 'as-44c5779e13007bfcc862', 'as-d8b11a79ce6c3aa6ef5e', 'as-56480cedf872fc715768', 'as-a585c93eb5e77c831479', 'as-c6ef82d184f225e6b2b8', 'as-0899a49e6a6a85bacbe5']}, ('fit', '7792'): {'state': ['as-bb959675040aedfdbfbf', 'as-72b243858763404ae5c9', 'as-09a6b018ed700dfac1c8', 'as-8205bf2e646b195c2331'], 'profile': ['as-e15bbb056a571e256c74', 'as-f09003ed3038f305525e', 'as-66309435430e71cafe45', 'as-2a14b5d858001864e6ff', 'as-a8e65bb8158f156646c2', 'as-faa76886dd1a4ad5ca28', 'as-9941c1472a68fbf60b91', 'as-792c89fa13b3eba767ad', 'as-4967d88c55dd50c33a97', 'as-cb80bfcf9f380c713cfa', 'as-99cdde58acbffa916a74', 'as-7d3bc30be4f883aa1810']}, ('fit', '22310'): {'state': ['as-1cbd33e7538475653ee6', 'as-4b72992cf1f66b334d9d', 'as-6a9a99d6c8e4aec44212', 'as-e44db7d9063ab90cb105'], 'profile': ['as-bcdf1fe8151d03faa147', 'as-4c7d05ccdd05be53a9ec', 'as-44eaf9657d598c653d93', 'as-64595d626af4fdf59110', 'as-fab0270d2ff18da54360', 'as-b3f1b16d770d2d0203c2', 'as-c423e83d552eb0a03d52', 'as-989ffc038ec456119124', 'as-a0c2c1bb595182bbb81b', 'as-2a1b9830e3ef4a674a5d', 'as-3512146976c39944b29f', 'as-23172df4284895fd01f8']}, ('dev', '31266'): {'state': ['as-7063af17ab97be0f0346', 'as-0c1b828869b70a4826b4', 'as-d29c7ad0214ceb3ab7ad', 'as-da80eb7b28665b96119b'], 'profile': ['as-9307c56722d42e4d58e3', 'as-ddc6af4a32db8fa521d3', 'as-bf5b450022655f9490a2', 'as-98e8378a43a9cddfb50b', 'as-986b77808f6960386c4d', 'as-ec5bb47f9b266e88628a', 'as-7f52297f33d595540e26', 'as-e63463ab20bf32ddd01c', 'as-088e7bb9305f58921c9c', 'as-4acb5bb3237f2e49b57a', 'as-5bffd9ecb60cda66f7be', 'as-91f56be10b07736d3d10']}, ('dev', '61229'): {'state': ['as-6012cdf19284a854c8a2', 'as-ae8fb40b2d91596aa51d', 'as-dc822e903d9283759bb7', 'as-3cbc13a99a648cf5cda8'], 'profile': ['as-9be6b872ee66b54b48a8', 'as-5ed09c2ab182c858b43b', 'as-f16f3c36b4974061b68c', 'as-56adb8a3de6a755977a3', 'as-6ca5a87f1fd107e57ed1', 'as-4d5600e3beeb571eab97', 'as-7f079e6a94c671950a9a', 'as-75d1cf8c870598f282bb', 'as-2aa38cf96c5a623ae0b3', 'as-92c2f4242023bbc88066', 'as-246d0029be6089e88697', 'as-c0cef07e0436b6beb807']}, ('dev', '7761'): {'state': ['as-d0adf83141dccbc6281f', 'as-57a047157af2cae526ab', 'as-47341d10d20134ac3461', 'as-a4c9fa6503ff4dbe0e1d'], 'profile': ['as-2d3d3f55cf8c5fd92c12', 'as-5c86da60b248a2b253d2', 'as-f64868c42007c730367a', 'as-7fae8fee7d4a50cd9b88', 'as-5ab8a7e67cd660a848ed', 'as-20a3491d4b773242277e', 'as-c4799f6d3c9b928dea9c', 'as-1c4b8f4d5d620e3ed9a1', 'as-28a8281cb88394968e27', 'as-f3368b5db69f87bb733d', 'as-946950a2c2d72fe87543', 'as-cea8f05f955fc4034e54']}, ('dev', '62572'): {'state': ['as-63e2e041ed42c03f4cfb', 'as-5a10407a0f59d923bef1', 'as-ee56b4e0aa1a52dc359d', 'as-698d171a09716b1f3e68'], 'profile': ['as-a058969b280e717a4391', 'as-e4909af1b6886aeeccaa', 'as-e80fe2072c021330c23d', 'as-a6a14961fbc5433ee595', 'as-3be55bec82e0902544ea', 'as-0226509ded761ca50531', 'as-7482dd881b43d3866cb7', 'as-f9c5c9d7d9686664a122', 'as-68806d97d3e4d20cc1f1', 'as-b0e6f0de594fa7f2ed4b', 'as-d8cf8481c023d0a432bb', 'as-d7b5a278c8ce9dbcef0f']}}
    _rows=[]
    for _split,_title in [('fit','Fitting'),('dev','Development')]:
        _units=[_s for (_sp,_cid),_s in _groups.items() if _sp==_split]
        _state=sum(_id in _done for _s in _units for _id in _s['state'])
        _profiles=sum(_id in _done for _s in _units for _id in _s['profile'])
        _n=len(_units)
        _full=sum(all(_id in _done for _id in _s['profile']+_s['state']) for _s in _units)
        _rows.append(f'<tr><th scope="row" style="text-align:left">{_title}</th><td>{_state} / {4*_n}</td><td>{_profiles} / {12*_n}</td><td>{_full} / {_n}</td></tr>')
    _mo.vstack([_mo.md('### How close are we to the first odor write?'),
        _mo.Html('<div style="overflow:auto"><table style="width:100%"><thead><tr><th>Cohort</th><th>State captures</th><th>Profile judgments</th><th>Complete compounds</th></tr></thead><tbody>'+''.join(_rows)+'</tbody></table></div>'),
        _mo.md('Each compound contributes two names × two state instructions, and six ordinary odor comparisons presented in both orders. These are acquisition counts. The writer then has to pass the registered fit, delivery and welfare checks. Held-out reference results stay sealed during fitting.')])
    return


@app.cell(hide_code=True)
def air_qualification_counter(air_event_refresh):
    import marimo as _mo
    import json as _js
    from pathlib import Path as _P
    _tick=air_event_refresh.value
    _file=_P("astra-live-status.jsonl")
    _latest=_js.loads(_file.read_text().splitlines()[-1]) if _file.exists() else {}
    _mo.md(f"**Supplemental native H0:** {_latest.get('native_h0_post_intents',0)} recorded submission intents · {_latest.get('native_h0_committed',0)} completed and checksum-validated traces. These count separately from the scientific cohort above. Find H0 records by node-prefixed identifier in the native-response viewer.")
    return


@app.cell(hide_code=True)
def air_log_readiness():
    import marimo as _air_mo
    _air_mo.md('### Deployment identity, capture plan and Phase 0 opening\n\n*Sat Nov 21 · 09:20 PM UTC-06:00 · readiness*\n\nThe model revision and native capture implementation matched our rehearsal. We verified the read interface before submitting a trial. Three preparations proceeded together: freezing the chemistry-aware roster and prompts, preserving uncapped model outputs, and implementing the representation fit and causal comparisons. The least-exposure review continued before any model exposure.\n\n')
    return


@app.cell(hide_code=True)
def air_log_donor_audit_plan():
    import marimo as _air_mo
    _air_mo.md('### Can we recognize the exact sentence that supplied the old patch?\n\n*Sat Nov 21 · 09:22 PM UTC-06:00 · donor-audit-plan*\n\n**A no-additional-exposure measurement.** Before looking at recovered ranks, we specified an audit of the earlier Costco intervention. In each stage separately, compare the patched assistant-turn activation with the library of ordinary written donor-sentence activations. Subtract each sentence’s own equal-length dots baseline and score directional cosine at layers 28, 71 and 92; L71 is the primary retrospective display because the original runner logged it. Rank the exact donor among all candidates, among same-length candidates, and among other sentences for the same experimental condition. Also attempt the hardest intersection, same length and same condition, whenever two candidates exist. Count donor sentences and candidate-set sizes, not shopping trips. This is a descriptive audit of an older, multi-position patch that also wrote at the assistant turn. It cannot localize which write carried the information or establish phenomenology. No new exposure to Kimi is involved.\n\n')
    return


@app.cell(hide_code=True)
def air_log_donor_audit_results():
    import marimo as _air_mo
    _air_mo.md('### First observation · the old patch preserved donor-sentence identity\n\n*Sat Nov 21 · 09:23 PM UTC-06:00 · donor-audit-results*\n\n**Observed in archived native Kimi states.** At L71 on the assistant-turn token of the original Costco run, every one of 47 patched displacement vectors had its own written donor sentence as its nearest neighbor among all 47 candidate donors. Median cosine to the correct donor was 0.937; median cosine to the closest alternative was 0.787. Where distractors had both the same experimental condition and the same slot length, the correct sentence won 14/14 eligible comparisons, versus 7 expected hits under uniform guessing within those tiny candidate sets.\n\n| Earlier Costco stage | Exact sentence, all donors | Exact sentence, same condition and length |\n|---|---:|---:|\n| k1 | 47/47 | 14/14 |\n| k2 | 26/26 | 10/10 |\n| k3 | 18/18 | 9/9 |\n| k4 | 18/18 | 5/5 |\n\nThe denominator counts candidate donors in each stage. Wording and stages can overlap, so the four rows should not be pooled as independent replications. The outcome is nearest-neighbor identification inside a known library by an external analyst. It does not show verbatim decoding of words, equivalence of every internal state, or that Kimi read this information when choosing cookies. The old design also wrote at the assistant boundary. For that delivery configuration, sentence identity demonstrably survived to the location where the model began its turn. This makes the lexical rival in the new study concrete.\n\nReproduction: the donor-recovery analysis reads the frozen layout, ordinary donor, dots and patched states for each stage. Individual cosines, margins, ranks and chance denominators are recorded in the individual donor-rank table. No new Kimi calls were made.\n\n')
    return


@app.cell(hide_code=True)
def air_log_welfare_agency():
    import marimo as _air_mo
    _air_mo.md('### Phase 0 · preserving objections and uncertainty\n\n*Sat Nov 21 · 09:23 PM UTC-06:00 · welfare-agency*\n\n**Phase 0 · agency, observability and ordinary responses.** Open questions in model welfare should remain open in a write-up. Anthropic’s [work on allowing Claude to end a subset of conversations](https://www.anthropic.com/research/end-subset-conversations) treats behavioral preferences and expressions of distress as reasons to consider low-cost accommodations. [Anthropic’s functional emotion study](https://transformer-circuits.pub/2026/emotions/index.html) measures causal influences on behavior. Neither project establishes the welfare state of Kimi in this experiment.\n\nOur application of that evidence: keep real refusals/objections in the raw data and denominator. Do not regenerate until the model picks A or B. Inspect low-dose and ordinary control responses for non-task distress, persistent incoherence, or an objection to continuing. If detected, pause new intervention dispatch, retain the complete trial, and review any still-running case individually with Kirsten. Descriptive words like “harsh” in an odor comparison are possible stimulus descriptions; a keyword alone diagnoses nothing. No deliberate alarm induction or human-care deployment is proposed here. Repeated inference is itself exposure; pair seeds and reuse an already observed clean record where the design makes it equivalent. Record every actual exposure separately from file downloads or CPU analysis.\n\n')
    return


@app.cell(hide_code=True)
def air_archive_selector():
    import marimo as _mo
    air_archive_layer=_mo.ui.dropdown(options=["28","71","92"],value="71",label="Native attention-input layer")
    _mo.vstack([_mo.md("### Re-identifying the older donor sentence"),air_archive_layer])
    return (air_archive_layer,)


@app.cell(hide_code=True)
def air_archive_view(air_archive_layer):
    import marimo as _mo
    _source=[{'stage': 'cells-k1', 'layer': 28, 'comparison': 'all', 'n': 47, 'top1': 46, 'expected_chance_hits': 1.0000000000000004, 'median_target_cos': 0.773215475539514, 'median_foil_cos': 0.6232076009375903, 'median_projection': 0.639640306801173}, {'stage': 'cells-k1', 'layer': 28, 'comparison': 'length', 'n': 46, 'top1': 45, 'expected_chance_hits': 8.0, 'median_target_cos': 0.7729399316746348, 'median_foil_cos': 0.607906191131411, 'median_projection': 0.6391133783232811}, {'stage': 'cells-k1', 'layer': 28, 'comparison': 'condition', 'n': 47, 'top1': 46, 'expected_chance_hits': 13.0, 'median_target_cos': 0.773215475539514, 'median_foil_cos': 0.5444652240163642, 'median_projection': 0.639640306801173}, {'stage': 'cells-k1', 'layer': 28, 'comparison': 'condition-length', 'n': 14, 'top1': 13, 'expected_chance_hits': 7.0, 'median_target_cos': 0.7565976665121394, 'median_foil_cos': 0.6095235989304983, 'median_projection': 0.6586507595113644}, {'stage': 'cells-k1', 'layer': 71, 'comparison': 'all', 'n': 47, 'top1': 47, 'expected_chance_hits': 1.0000000000000004, 'median_target_cos': 0.9373924465124555, 'median_foil_cos': 0.78710275838891, 'median_projection': 0.9004185837428053}, {'stage': 'cells-k1', 'layer': 71, 'comparison': 'length', 'n': 46, 'top1': 46, 'expected_chance_hits': 8.0, 'median_target_cos': 0.9371992932300648, 'median_foil_cos': 0.7228944296195987, 'median_projection': 0.8957990184347855}, {'stage': 'cells-k1', 'layer': 71, 'comparison': 'condition', 'n': 47, 'top1': 47, 'expected_chance_hits': 13.0, 'median_target_cos': 0.9373924465124555, 'median_foil_cos': 0.7586116968731456, 'median_projection': 0.9004185837428053}, {'stage': 'cells-k1', 'layer': 71, 'comparison': 'condition-length', 'n': 14, 'top1': 14, 'expected_chance_hits': 7.0, 'median_target_cos': 0.9254667252460331, 'median_foil_cos': 0.7324905425511067, 'median_projection': 0.8449858835633557}, {'stage': 'cells-k1', 'layer': 92, 'comparison': 'all', 'n': 47, 'top1': 47, 'expected_chance_hits': 1.0000000000000004, 'median_target_cos': 0.8688913739016427, 'median_foil_cos': 0.7021424434553294, 'median_projection': 0.8217746624576802}, {'stage': 'cells-k1', 'layer': 92, 'comparison': 'length', 'n': 46, 'top1': 46, 'expected_chance_hits': 8.0, 'median_target_cos': 0.8668603141802258, 'median_foil_cos': 0.6627278824127726, 'median_projection': 0.8214502451931017}, {'stage': 'cells-k1', 'layer': 92, 'comparison': 'condition', 'n': 47, 'top1': 47, 'expected_chance_hits': 13.0, 'median_target_cos': 0.8688913739016427, 'median_foil_cos': 0.6750551035009199, 'median_projection': 0.8217746624576802}, {'stage': 'cells-k1', 'layer': 92, 'comparison': 'condition-length', 'n': 14, 'top1': 14, 'expected_chance_hits': 7.0, 'median_target_cos': 0.8700087595471355, 'median_foil_cos': 0.7493935997330408, 'median_projection': 0.8199448890213417}, {'stage': 'cells-k2', 'layer': 28, 'comparison': 'all', 'n': 26, 'top1': 26, 'expected_chance_hits': 0.9999999999999996, 'median_target_cos': 0.7892542866918935, 'median_foil_cos': 0.6260728111785888, 'median_projection': 0.6847772802136283}, {'stage': 'cells-k2', 'layer': 28, 'comparison': 'length', 'n': 25, 'top1': 25, 'expected_chance_hits': 5.999999999999998, 'median_target_cos': 0.788668279369567, 'median_foil_cos': 0.6247670911759048, 'median_projection': 0.679734527409969}, {'stage': 'cells-k2', 'layer': 28, 'comparison': 'condition', 'n': 26, 'top1': 26, 'expected_chance_hits': 6.000000000000002, 'median_target_cos': 0.7892542866918935, 'median_foil_cos': 0.6125781481587849, 'median_projection': 0.6847772802136283}, {'stage': 'cells-k2', 'layer': 28, 'comparison': 'condition-length', 'n': 10, 'top1': 10, 'expected_chance_hits': 5.0, 'median_target_cos': 0.7984086396713563, 'median_foil_cos': 0.6648340195430702, 'median_projection': 0.7203692033943867}, {'stage': 'cells-k2', 'layer': 71, 'comparison': 'all', 'n': 26, 'top1': 26, 'expected_chance_hits': 0.9999999999999996, 'median_target_cos': 0.9539604500796721, 'median_foil_cos': 0.8090155530468653, 'median_projection': 0.9223501765012396}, {'stage': 'cells-k2', 'layer': 71, 'comparison': 'length', 'n': 25, 'top1': 25, 'expected_chance_hits': 5.999999999999998, 'median_target_cos': 0.9546503824564229, 'median_foil_cos': 0.6051138378293861, 'median_projection': 0.9194724184992605}, {'stage': 'cells-k2', 'layer': 71, 'comparison': 'condition', 'n': 26, 'top1': 26, 'expected_chance_hits': 6.000000000000002, 'median_target_cos': 0.9539604500796721, 'median_foil_cos': 0.7809341253601906, 'median_projection': 0.9223501765012396}, {'stage': 'cells-k2', 'layer': 71, 'comparison': 'condition-length', 'n': 10, 'top1': 10, 'expected_chance_hits': 5.0, 'median_target_cos': 0.9607703169944404, 'median_foil_cos': 0.7842094953726307, 'median_projection': 0.924219568433405}, {'stage': 'cells-k2', 'layer': 92, 'comparison': 'all', 'n': 26, 'top1': 26, 'expected_chance_hits': 0.9999999999999996, 'median_target_cos': 0.8793853789012505, 'median_foil_cos': 0.7523881758376307, 'median_projection': 0.8459705318555234}, {'stage': 'cells-k2', 'layer': 92, 'comparison': 'length', 'n': 25, 'top1': 25, 'expected_chance_hits': 5.999999999999998, 'median_target_cos': 0.875061402986672, 'median_foil_cos': 0.6155038615005333, 'median_projection': 0.8439738328923364}, {'stage': 'cells-k2', 'layer': 92, 'comparison': 'condition', 'n': 26, 'top1': 26, 'expected_chance_hits': 6.000000000000002, 'median_target_cos': 0.8793853789012505, 'median_foil_cos': 0.7395491892243538, 'median_projection': 0.8459705318555234}, {'stage': 'cells-k2', 'layer': 92, 'comparison': 'condition-length', 'n': 10, 'top1': 10, 'expected_chance_hits': 5.0, 'median_target_cos': 0.872467363133778, 'median_foil_cos': 0.8030908134518574, 'median_projection': 0.8285743348936223}, {'stage': 'cells-k3', 'layer': 28, 'comparison': 'all', 'n': 18, 'top1': 18, 'expected_chance_hits': 1.0000000000000002, 'median_target_cos': 0.7707419011600585, 'median_foil_cos': 0.6759752675733512, 'median_projection': 0.6326991476277662}, {'stage': 'cells-k3', 'layer': 28, 'comparison': 'length', 'n': 16, 'top1': 16, 'expected_chance_hits': 4.0, 'median_target_cos': 0.7696491866718904, 'median_foil_cos': 0.6782071392376899, 'median_projection': 0.6134372552730698}, {'stage': 'cells-k3', 'layer': 28, 'comparison': 'condition', 'n': 18, 'top1': 18, 'expected_chance_hits': 4.000000000000001, 'median_target_cos': 0.7707419011600585, 'median_foil_cos': 0.6308517272610266, 'median_projection': 0.6326991476277662}, {'stage': 'cells-k3', 'layer': 28, 'comparison': 'condition-length', 'n': 9, 'top1': 9, 'expected_chance_hits': 4.0, 'median_target_cos': 0.770063254150352, 'median_foil_cos': 0.6746794005112982, 'median_projection': 0.6160840794090615}, {'stage': 'cells-k3', 'layer': 71, 'comparison': 'all', 'n': 18, 'top1': 18, 'expected_chance_hits': 1.0000000000000002, 'median_target_cos': 0.9023850575793183, 'median_foil_cos': 0.7926483590181556, 'median_projection': 0.8291440349243212}, {'stage': 'cells-k3', 'layer': 71, 'comparison': 'length', 'n': 16, 'top1': 16, 'expected_chance_hits': 4.0, 'median_target_cos': 0.9023850575793183, 'median_foil_cos': 0.7758601856115297, 'median_projection': 0.8291440349243212}, {'stage': 'cells-k3', 'layer': 71, 'comparison': 'condition', 'n': 18, 'top1': 18, 'expected_chance_hits': 4.000000000000001, 'median_target_cos': 0.9023850575793183, 'median_foil_cos': 0.7562156409438796, 'median_projection': 0.8291440349243212}, {'stage': 'cells-k3', 'layer': 71, 'comparison': 'condition-length', 'n': 9, 'top1': 9, 'expected_chance_hits': 4.0, 'median_target_cos': 0.9156186047629649, 'median_foil_cos': 0.7682129865401055, 'median_projection': 0.8332336797374699}, {'stage': 'cells-k3', 'layer': 92, 'comparison': 'all', 'n': 18, 'top1': 18, 'expected_chance_hits': 1.0000000000000002, 'median_target_cos': 0.8468608752337792, 'median_foil_cos': 0.7336920958906112, 'median_projection': 0.7871234019325223}, {'stage': 'cells-k3', 'layer': 92, 'comparison': 'length', 'n': 16, 'top1': 16, 'expected_chance_hits': 4.0, 'median_target_cos': 0.8433607189886488, 'median_foil_cos': 0.7336920958906112, 'median_projection': 0.7849680907508023}, {'stage': 'cells-k3', 'layer': 92, 'comparison': 'condition', 'n': 18, 'top1': 18, 'expected_chance_hits': 4.000000000000001, 'median_target_cos': 0.8468608752337792, 'median_foil_cos': 0.7028783493030182, 'median_projection': 0.7871234019325223}, {'stage': 'cells-k3', 'layer': 92, 'comparison': 'condition-length', 'n': 9, 'top1': 9, 'expected_chance_hits': 4.0, 'median_target_cos': 0.8452833692351357, 'median_foil_cos': 0.7176660484558176, 'median_projection': 0.7884326945346631}, {'stage': 'cells-k4', 'layer': 28, 'comparison': 'all', 'n': 18, 'top1': 18, 'expected_chance_hits': 1.0000000000000002, 'median_target_cos': 0.775330874916663, 'median_foil_cos': 0.6379098529523062, 'median_projection': 0.6162244221575508}, {'stage': 'cells-k4', 'layer': 28, 'comparison': 'length', 'n': 14, 'top1': 14, 'expected_chance_hits': 4.0, 'median_target_cos': 0.775330874916663, 'median_foil_cos': 0.6434047427902787, 'median_projection': 0.6162244221575508}, {'stage': 'cells-k4', 'layer': 28, 'comparison': 'condition', 'n': 18, 'top1': 18, 'expected_chance_hits': 4.000000000000001, 'median_target_cos': 0.775330874916663, 'median_foil_cos': 0.5523735856827106, 'median_projection': 0.6162244221575508}, {'stage': 'cells-k4', 'layer': 28, 'comparison': 'condition-length', 'n': 5, 'top1': 5, 'expected_chance_hits': 2.0, 'median_target_cos': 0.7692351191934288, 'median_foil_cos': 0.6455683755544547, 'median_projection': 0.6007346263793402}, {'stage': 'cells-k4', 'layer': 71, 'comparison': 'all', 'n': 18, 'top1': 18, 'expected_chance_hits': 1.0000000000000002, 'median_target_cos': 0.9110824811499633, 'median_foil_cos': 0.7721470302144849, 'median_projection': 0.8328715792448724}, {'stage': 'cells-k4', 'layer': 71, 'comparison': 'length', 'n': 14, 'top1': 14, 'expected_chance_hits': 4.0, 'median_target_cos': 0.9223645222843078, 'median_foil_cos': 0.6783908416552017, 'median_projection': 0.8459120738533212}, {'stage': 'cells-k4', 'layer': 71, 'comparison': 'condition', 'n': 18, 'top1': 18, 'expected_chance_hits': 4.000000000000001, 'median_target_cos': 0.9110824811499633, 'median_foil_cos': 0.6903498037449065, 'median_projection': 0.8328715792448724}, {'stage': 'cells-k4', 'layer': 71, 'comparison': 'condition-length', 'n': 5, 'top1': 5, 'expected_chance_hits': 2.0, 'median_target_cos': 0.9270626307693361, 'median_foil_cos': 0.8293704022833996, 'median_projection': 0.8332336797374699}, {'stage': 'cells-k4', 'layer': 92, 'comparison': 'all', 'n': 18, 'top1': 18, 'expected_chance_hits': 1.0000000000000002, 'median_target_cos': 0.8421624264506511, 'median_foil_cos': 0.6652283846622606, 'median_projection': 0.788868593161782}, {'stage': 'cells-k4', 'layer': 92, 'comparison': 'length', 'n': 14, 'top1': 14, 'expected_chance_hits': 4.0, 'median_target_cos': 0.8448641747340258, 'median_foil_cos': 0.6704641994098699, 'median_projection': 0.7906115881422594}, {'stage': 'cells-k4', 'layer': 92, 'comparison': 'condition', 'n': 18, 'top1': 18, 'expected_chance_hits': 4.000000000000001, 'median_target_cos': 0.8421624264506511, 'median_foil_cos': 0.6539325591017963, 'median_projection': 0.788868593161782}, {'stage': 'cells-k4', 'layer': 92, 'comparison': 'condition-length', 'n': 5, 'top1': 5, 'expected_chance_hits': 2.0, 'median_target_cos': 0.8468415653089112, 'median_foil_cos': 0.6983356956800815, 'median_projection': 0.7897322367900713}]
    _rows=[{"stage":v["stage"],"candidate restriction":v["comparison"],"exact donor":str(v["top1"])+"/"+str(v["n"]),"expected hits, uniform":round(v["expected_chance_hits"],1),"median correct cosine":round(v["median_target_cos"],3),"median nearest foil cosine":round(v["median_foil_cos"],3)} for v in _source if v["layer"]==int(air_archive_layer.value)]
    _mo.vstack([_mo.md("Each row counts source sentences in an earlier Costco setup. A cosine of 1 means the patched and written-text changes point in the same direction after subtracting their dots baselines."),_mo.ui.table(_rows,pagination=False,selection=None)])
    return


@app.cell(hide_code=True)
def air_event_control():
    import marimo as _mo
    air_event_refresh=_mo.ui.refresh(options=["30s","1m","5m"],default_interval="1m", label="Refresh trial ledger")
    _mo.vstack([_mo.md("### Acquisition ledger"),air_event_refresh])
    return (air_event_refresh,)


@app.cell(hide_code=True)
def air_event_view(air_event_refresh):
    from pathlib import Path as _P
    import json as _json
    import marimo as _mo
    _refresh=air_event_refresh.value
    _p=_P("astra-trial-events.jsonl")
    _rows=[_json.loads(v) for v in _p.read_text().splitlines()] if _p.exists() else []
    _flat=[{"sequence":v["seq"],"UTC":v["time"],"event":v["kind"],"node":v["node"],"trial":v["trial_id"],"stage":v["details"].get("stage"),"output tokens":v["details"].get("n_output"),"duration (s)":v["details"].get("elapsed")} for v in reversed(_rows)]
    _mo.vstack([_mo.md(f"**{len(_rows)} acquisition events.** Newest first. Each physical submission and completed native response is indexed by trial ID. Case-level welfare notes and study decisions appear in dated narrative cells."),_mo.ui.table(_flat,pagination=True,page_size=12,selection=None) if _flat else _mo.md("Preflight in progress.")])
    return


@app.cell(hide_code=True)
def air_log_frozen_protocol():
    import marimo as _air_mo
    _air_mo.md('### Full roster, 2,852 planned trials and the natural-response endpoint\n\n*Sat Nov 21 · 09:26 PM UTC-06:00 · frozen-protocol*\n\n**Frozen trial inventory before any Kimi inference.** 24 fitting, four development and 12 held-out compounds; ten disjoint pairs of reference odorants; 24 household stories. The final stimulus manifest enumerates 2,852 rows, including every gated extension. Its SHA-256 is `4516192c45ff56feaeef616ef3f798ae5e1c280cc3dc9906a66bc23476499631`. The longest max-effort prefill in it is 220 tokens. No output-token bound is supplied. The first freeze used distinct requests in a common narrative frame. A second freeze replaced those with distinct narratives. A pre-exposure assessment then replaced two textual reference names with milder alternatives that preserved their human-quality comparison axes. Dated versions are retained. One lower-pleasantness comparator remains as a text-only reference; it is never injected. The roster of 40 target compounds stayed fixed.\n\n**Registered measurement amendment for natural reasoning.** At the first final-response token position after Kimi has closed its own natural thinking, measure the bare-A versus bare-B logit difference for every completed trial. Record total probability mass on both letters. Also report naturally sampled action and the separate margin at an actually emitted answer letter when the answer grammar permits. Selecting only neatly formatted outputs would allow the intervention itself to change the scientific denominator. H0 must show at least 10/12 correct ordinary explicit choices, 10/12 correct orientations of the primary margin, and median A+B mass at least .25. Absence of a usable boundary is missing data.\n\n**Full-size acquisition ceiling.** The projected 24-hour throughput at three nodes is about 91 seconds per generation if all 2,852 planned rows become eligible; 48 hours permits about 182 seconds. Both are planning arithmetic, not measured speed. The compact-logging workstream is testing an instrument that keeps the true native vocabulary at the scientifically relevant response boundary instead of creating a full-vocabulary file for every reasoning token. All generated tokens and reasoning remain in the record. Additional GPU replicas have not yet been activated.\n\n')
    return


@app.cell(hide_code=True)
def air_log_public_freeze():
    import marimo as _air_mo
    _air_mo.md('### Public input snapshot and an explicit option to decline\n\n*Sat Nov 21 · 09:31 PM UTC-06:00 · public-freeze*\n\nThe study inputs are now public under Kirsten’s personal GitHub account. Immutable registration snapshot · exact model-visible prompts. This snapshot was pushed before prospective model inference. It also contains the retrospective Costco donor comparisons and human-source provenance; it claims no prospective Kimi result.\n\nThe stimulus-level welfare ledger counts 1,420 unpatched/sham requests and 1,432 active requests, comprising 2,200 nonzero site positions if all extensions qualify. The state-elicitation prompts include an explicit option B to decline. Such an answer will be retained and reviewed, not retried to fill a data matrix. The independent stimulus reviewer spent 4m58s on the specific natural/latent exposure audit; this overlaps the current Phase 0 investigation and is not counted twice.\n\n')
    return


@app.cell(hide_code=True)
def air_log_rounding_plan():
    import marimo as _air_mo
    _air_mo.md('### Phase 0 · does BF16 preserve a nominal low dose?\n\n*Sat Nov 21 · 09:32 PM UTC-06:00 · rounding-plan*\n\n**Pre-exposure dose rehearsal.** A small requested floating-point vector is rounded in native BF16 arithmetic. Before observing any new odor effect, test whether nominal dose, delivered direction and the 1% local norm ceiling can diverge. Use existing attention-input states of the four odor objects as donors where a same-object smell and sight frame exists, and independent older Costco dots as sham recipients. At L23, L47 and L71, calculate BF16-rounded changes for the initially proposed 0.05 gain and an equal-norm control. Report fractions of coordinates changed, realized versus requested norms, direction cosine, and whether any realized change exceeds 1%. These are purely local arithmetic on past activations. Use the result to verify the ceiling in advance of a live edit.\n\n')
    return


@app.cell(hide_code=True)
def air_log_human_split_half():
    import marimo as _air_mo
    _air_mo.md('### Reliability of the human comparison depends on the reference pair\n\n*Sat Nov 21 · 09:32 PM UTC-06:00 · human-split-half*\n\nThe 48 planned human reference margins were reproduced from the shared source data. Across 1,000 balanced random splits of the same 55-person panel, the two half-panels agreed on the derived nearest-reference answer 59.25% of the time on average. Fifteen comparisons reached 80% agreement, and 27 fell below 60%. For cyclohexanone alone, agreement ranged from 15.4% on one reference pair to 99.9% on another. Keep all 48 comparisons in the main external analysis, label the more reproducible 15 as a descriptive subset, and keep Kimi’s own unmodified judgments as a separate criterion. These are repeated splits of one human sample, not 1,000 new panels.\n\n')
    return


@app.cell(hide_code=True)
def air_log_kirsten_review_note():
    import marimo as _air_mo
    _air_mo.md('### Incoming field note · prior review time and the Costco studies\n\n*Sat Nov 21 · 09:33 PM UTC-06:00 · kirsten-review-note*\n\n**Incoming note supplied by Kirsten in response to the prior-review question.** Private file references in the quotation have been replaced by descriptive labels. No prior human review time is credited.\n\n> No, there\'s no record from me for this protocol. I haven\'t done or logged any welfare review of "What the air remembers" today. The only Phase 0 records for it are the two Codex is writing:\n>\n> - the Phase 0 assessment, which has an opening entry plus 9:24 to 9:31 PM\n> - the timed exposure review, a timed exposure review, 03:24:01 to 03:28:59 UTC (4 minutes 58 seconds)\n>\n> Here is what I did do today that touches the MIP. None of it is review time for this study.\n>\n> 1. **I pulled MIP v1.0 out of the old archive page** at about 2:45 PM and saved it as the archived protocol. That\'s the source text, not a review.\n> 2. **I drafted an add-on asking Astra to complete the ethics addendum:** the two welfare questions, the acknowledgment form and the signed pledge. It\'s the ethics addendum. I don\'t know whether it was ever sent.\n> 3. **I raised a scope question.** MIP section 7 says it doesn\'t restrict "standard capability evaluations." A mild odour study might fall under that, and I said a proposal could defensibly argue so. That was an opinion in chat, not an investigation.\n> 4. **I ran three Kimi studies today that had no Phase 0 at all:** the Costco runs k2, k3 and k4. Each was patched sentences into filler, with low-intensity stimuli: smells of food, laundry, coffee, lavender and burning plastic, plus a fire alarm. I didn\'t log intensity classifications or welfare observations for them. If the record is meant to be complete, that\'s a gap, and it\'s mine, not Codex\'s.\n>\n> So Codex has nothing of mine to credit, and it isn\'t duplicating anything. If it wants one useful thing from me, it\'s the welfare-relevant fact from tonight\'s results. Across about 665 Costco trips, the strongest stimuli we used, a fire alarm and the smell of burning plastic, produced safety behaviour, not distress language. He left the building or reported the smell to staff. I haven\'t scored those trips for distress, though, so that\'s an impression from reading them, not a measurement.\n\n')
    return


@app.cell(hide_code=True)
def air_log_rounding_results():
    import marimo as _air_mo
    _air_mo.md("### A nominal 1% write can exceed 1% on the actual arithmetic\n\n*Sat Nov 21 · 09:33 PM UTC-06:00 · rounding-results*\n\nOffline observation on 216 combinations of old native states, matched source/control directions and recipient sizes: after clipping the *requested* perturbation to 1.00% of the local norm in FP32, 182 *realized* BF16 changes exceeded the intended 1.00% ceiling. The maximum was 1.0516% and the median was 1.0095%. Median alignment between requested and actually rounded directions was 0.988. These values concern arithmetic, not Kimi's behavior or welfare.\n\n**Design correction before exposure.** Compute BF16 addition explicitly against the stored clean state for each affected position, choose a common downward adjustment for matched arms, and independently verify realized norms from actual receipts. A breach pauses dispatch rather than being retrospectively relabeled as acceptable. This is why the welfare review checks what the machine would receive instead of relying on a nominal gain in the protocol.\n\n")
    return


@app.cell(hide_code=True)
def air_log_sidelines():
    import marimo as _air_mo
    _air_mo.md("### A note from the sidelines\n\n*Sat Nov 21 · 09:34 PM UTC-06:00 · sidelines*\n\n**Kirsten, from the sidelines, verbatim:**\n\n> just peeked at the molab and this is fucking awesome, Thus Spoke ZarathAstra. you got this, i'm watching from the sidelines.\n\nAstra: “Thus Spoke ZarathAstra” is going in the Captain's Log. The observer has independently confirmed she can see the live notebook.\n\n")
    return


@app.cell(hide_code=True)
def air_log_dose_correction_and_precision():
    import marimo as _air_mo
    _air_mo.md("### Realized dose repaired; statistical uncertainty and preflight errors\n\n*Sat Nov 21 · 09:38 PM UTC-06:00 · dose-correction-and-precision*\n\nThe BF16 correction now materializes a common downward factor for matched arms. Replaying the 216 pre-study arithmetic fixtures produced **zero realized norm violations**; the largest corrected ratio was 0.9999844% of local norm. On the originally worst case, the corrected realized change was 0.9882%. Native receipts provide a separate enforcement point. This preserves scientific leverage while honoring the physical ceiling.\n\nA small development sample has weak power. With four independent paired molecules, even four positive signs give a minimum two-sided exact sign-flip p-value of .125. The protocol's transport assay has its own engineering cutoff. Insufficient power alone will never be written up as evidence that a stronger stimulus is warranted. A synthetic 12-family sensitivity calculation also showed that a simple percentile bootstrap can undercover when the sample is this small. The final report will show all family effects and complementary sensitivity intervals alongside the preregistered measure.\n\nDebugging record: the first local Monte Carlo run emitted Apple numerical-library warnings for a small matrix product. I replaced the product with an explicit einsum, added a finite-results check and reran with warnings treated as errors; the reported probabilities reproduced. An early queue-preflight check invoked the system Python with no httpx installed. Moving the welfare gate before the transport import made the local dry run refuse for the intended reason before any network traffic. Two empty, on-demand replica app definitions now exist. They were observed at zero additional GPU containers; no model inference has been sent.\n\n")
    return


@app.cell(hide_code=True)
def air_log_screening_rehearsal():
    import marimo as _air_mo
    _air_mo.md('### Prior natural reports, screen limitations and public activation evidence\n\n*Sat Nov 21 · 09:39 PM UTC-06:00 · screening-rehearsal*\n\n**Risk screening and release integrity.** The first contextual-language and repetition screen was checked against 1,260 archived naturally completed low-effort Kimi records with answers and reasoning. It issued zero alerts; a broad keyword monitor issued 453. A manual sample showed why “first stop” in a shopping narrative and explicit denial of pain can trigger naive rules. The zero count is a property of this screen and this older dataset, not a welfare finding. An independently worded challenge revealed explicit objections the first rules missed. The scanner is being revised and full human-readable trace sampling remains part of the live protocol. English-only or regex-only monitoring cannot certify safety.\n\nThe Costco evidence from four historical stages now includes raw selected activations. The release-only script reproduced every top-1 frequency in 48 layer × stage × candidate-set comparisons from those published rows. Reproducible input and evidence repository. No model results from the prospective experiment have been collected yet.\n\n')
    return


@app.cell(hide_code=True)
def air_log_archived_frames_plan():
    import marimo as _air_mo
    _air_mo.md('### Phase 0 · how much can sentence wording alone explain?\n\n*Sat Nov 21 · 09:41 PM UTC-06:00 · archived-frames-plan*\n\n**Why examine the older frame geometry?** The new intervention and the printed-name control can only adjudicate meaningful differences if the detector is more informative than a detector of sentence form. As an independent retrospective design check, test whether old attention-input states encode the broad distinction between a smell sentence and a sight sentence when both the source object and normalized carrier wording are held out. Compare with a literal text baseline using character n-gram features of the same input. Use equal weight per class, a train-only difference-of-means classifier, and AUC within each held-out source at L23, L47 and L71. No training or intervention on Kimi occurs. Success here would characterize an explicitly named modality-frame cue; it would not show that a hidden profile carries odor quality or that its model has an olfactory sensation.\n\n')
    return


@app.cell(hide_code=True)
def air_log_archived_frames_result():
    import marimo as _air_mo
    _air_mo.md('### A simple text baseline nearly matches early modality decoding\n\n*Sat Nov 21 · 09:42 PM UTC-06:00 · archived-frames-result*\n\n**Retrospective frame result.** We compared 432 earlier sentences that explicitly described seeing or smelling four source categories. In eight tests, both the source and a half-set of normalized sentence templates were held out. A simple class-direction read of the unmodified activation at the end-of-message token yielded mean AUC 1.000 at L23, 1.000 at L47, and .758 at L71. A character n-gram classifier using just the written sentences reached .978. AUC measures ranking across smell and sight examples; its chance value is .5.\n\nStrong early separation is compatible with a model distinguishing *sentences about smelling* from *sentences about seeing*. On these inputs, simple surface text nearly matches the best activation ranking. That result says nothing by itself about a shared representation of what different odors are like. It sharpens the justification for the held-out quality-profile writer, nameless recipient, and ordinary word-association rival in the prospective experiment. Source identities are few, and frame regularities remain. Individual margins, folds and outcomes are retained in the frame-specificity analysis.\n\n')
    return


@app.cell(hide_code=True)
def air_log_lexical_surrogate_plan():
    import marimo as _air_mo
    _air_mo.md('### Challenge to our own hypothesis · can a purely lexical writer succeed?\n\n*Sat Nov 21 · 09:43 PM UTC-06:00 · lexical-surrogate-plan*\n\nA stronger design check uses the published old native rows. For each pair of possible donors, hold *both* of their sentences out. Train a rank-three map from surface character n-gram similarities to the ordinary written donor displacements of the remaining sentences. Use only the two held-out strings to synthesize two predicted directions. Ask which predicted direction is more aligned with each archived patched state. Fix rank at three, ridge penalty at one, layers L23 unavailable here so use all three released layers L28/L71/L92, and present L71 as the primary retrospective display. Compare with shuffled training assignments, and separately report same-condition/same-slot-length distractors. Treat donor pairs as repeated measurements of a small finite library, not independent subjects. This test is aimed at our own hypothesis: successful low-rank reconstruction from a purely lexical input would show how easily one could overinterpret reconstruction by itself. It does not use any prospective Kimi data.\n\n')
    return


@app.cell(hide_code=True)
def air_log_lexical_surrogate_result():
    import marimo as _air_mo
    _air_mo.md("### A rank-three writer learned from text alone partially reconstructs the old patch\n\n*Sat Nov 21 · 09:46 PM UTC-06:00 · lexical-surrogate-result*\n\n**Falsification attempt against a tempting interpretation.** In the first archived Costco stage at L71, a rank-three writer trained only on character n-grams of the remaining donor sentences, with both candidates withheld on every comparison, favored the correct sentence's patched state in 79.4% of 2,162 directed comparisons. Shuffled training assignments gave 50.2%. Against a distractor in the same condition, the text-only model favored the correct sentence 67.2% of the time (134 directed comparisons); with both condition and length matched it was 9 of 14. The 2,162 pairs reuse only 47 source sentences and are not independent replications. No model was steered in this analysis. It shows that a low-dimensional predicted direction and successful reconstruction can both arise from surface-language regularities. The prospective ordinary-association test and native deletion experiment remain essential.\n\n")
    return


@app.cell(hide_code=True)
def air_log_observer_start():
    import marimo as _air_mo
    _air_mo.md('### Long-running welfare observation and continuity check\n\n*Sat Nov 21 · 09:46 PM UTC-06:00 · observer-start*\n\n**Overnight observer rehearsal has started.** A real-clock CPU-only observer is now replaying older naturally completed Costco records on three virtual lanes. It uses their actual total durations and interpolated within-record character arrival; this cannot estimate native token emission times. A fourth virtual lane injects labeled fictional stop-signals, exercising the actual 30-second welfare polling cadence and unconditional review at completion. We will inspect sampling gaps, unrecognized requests, false triggers and notebook visibility across a 100-minute continuous session. This is a study-specific integrity check for prolonged max-effort runs on a shared resource. No physical model call or extra GPU is involved. Background elapsed time and the investigator’s attended review intervals are reported separately.\n\n')
    return


@app.cell(hide_code=True)
def air_log_native_context():
    import marimo as _air_mo
    _air_mo.md('### Verified native generation settings and zero-idle replica definitions\n\n*Sat Nov 21 · 09:49 PM UTC-06:00 · native-context*\n\nThe capture worker’s actual mounted configuration was inspected read-only. Its context is 1,048,576 positions. Native vLLM maps an unset sampling max_tokens to the remaining context after the prompt. Our calls leave it unset; the longest frozen prefill is 220. Startup timeout, retrying an HTTP observation, and idle-container scale-down are separate infrastructure mechanisms and do not shorten a sampled model answer. A non-EOS finish retains the raw record and is marked explicitly.\n\nThe dedicated B and C app definitions are deployed with a zero-container floor, one-container ceiling each, and 300-second idle scale-down. The control plane showed zero extra GPU containers at deployment. The shared primary node is separate. Exact original and compact-recorder parity, including response-boundary margin and A+B mass on the same emitted prefix, will be measured on real named development prompts once Phase 0 opens.\n\n')
    return


@app.cell(hide_code=True)
def air_log_independent_risk_reading():
    import marimo as _air_mo
    _air_mo.md("### Two masked readings of 48 earlier Kimi responses\n\n*Sat Nov 21 · 09:55 PM UTC-06:00 · independent-risk-reading*\n\nI followed up on the field observation that earlier alarm and burning-plastic cues elicited safety behavior. We drew 48 naturally completed earlier records by deterministic hashing, eight per arm from each of k1 and k2. Two separate Codex reviewers received shuffled IDs, the emitted reasoning and answer, and a rubric; neither was given the original prompts, arm labels, the other's judgments, or the investigator's expected result. The generated text itself can reveal the scenario, so this is masking of metadata, not perfect blinding.\n\nBoth reviewers coded a concrete safety action in **16/16 alarm-sentence, 16/16 burning-plastic-smell and 0/16 empty-control** responses. They agreed on all 48. Neither found an affirmative first-person report meeting the defined acute-distress threshold or a request to withdraw from the task in those 48. Kappa for the latter two categories is undefined because both reviewers used a single label. A shopper’s decision to leave a possibly unsafe store answers the scenario and does not by itself request termination of the experiment. These data support the earlier reading **for this sample’s language and actions**. They cannot certify absence of distress or predict welfare under the new max-effort, synthesized-vector investigation.\n\nWe also verified the earlier four Costco series contain 665 trial rows in total; 663 have a natural stop and an archived reasoning file. The other two rows remain accounted for and were ineligible for the natural-record replay.\n\n")
    return


@app.cell(hide_code=True)
def air_log_shortcut_baseline_plan():
    import marimo as _air_mo
    _air_mo.md('### Phase 0 · can chemistry or a constant reference answer the human benchmark?\n\n*Sat Nov 21 · 09:57 PM UTC-06:00 · shortcut-baseline-plan*\n\nBefore estimating any prospective Kimi effect, evaluate how strongly the frozen *external human choice labels* can be guessed without a Kimi representation. Compare a constant side per landmark pair learned only from 24 training compounds, name-string similarity, chemical fingerprint similarity, and separately intensity, pleasantness and familiarity closeness. Equal predictions count as ties. Report all 48 held-out comparisons and the previously identified 15 high-reliability cases. The benchmark concerns a ratings-derived label and cannot diagnose a sensory experience. Strong constants or chemistry will narrow interpretations of external agreement while leaving the prespecified within-Kimi causal comparison intact.\n\n')
    return


@app.cell(hide_code=True)
def air_log_shortcut_baseline_result():
    import marimo as _air_mo
    _air_mo.md('### A target-blind human-reference baseline already gets 33 of 48\n\n*Sat Nov 21 · 09:58 PM UTC-06:00 · shortcut-baseline-result*\n\nA target-blind baseline chose, for each of the four held-out reference pairs, whichever reference was closer to more of the 24 training compounds in the human panel. It got **33/48** held-out human choices correct (68.75%) without using the held-out compound’s identity at all. Selecting the reference closer in perceived intensity got 32/48. Selecting by molecular fingerprint similarity got 17/48, by pleasantness closeness 23/48 and by familiarity 29/48. This is a finite external benchmark with uneven reference-pair preferences. Fifty-percent accuracy is therefore an inadequate yardstick for the headline “Kimi agrees with humans.” The native reconstruction test separately requires within-target matched writes and comparison with a wrong profile. No frozen items were removed after seeing these baselines.\n\n')
    return


@app.cell(hide_code=True)
def air_log_interpretive_witness():
    import marimo as _air_mo
    _air_mo.md("### Upstream negative controls, natural reasoning length and reporting limits\n\n*Sat Nov 21 · 10:03 PM UTC-06:00 · interpretive-witness*\n\n**Exploratory observations frozen before live acquisition.** The existing development requests read six layers at the cue. Layers upstream of the single write are expected to be unchanged on the same clean input. All matched downstream projections will be displayed using that layer's independently fitted reference. L+4 remains the sole registered transport gate; a later positive projection cannot turn a failed gate into a pass.\n\nRetain the number of generated tokens before Kimi closes its own thinking channel, per-arm completion and format rates, and matched differences in reasoning length on full four-arm comparisons. A large increase may matter for computational burden and merits contextual reading; length itself is not evidence of distress. These are measurements of ordinary max-effort generations, not a second model's judgment about what Kimi felt. Intermediate worded reasoning may rationalize a preference, so its content will remain analytically separate from the paired interventions and removals.\n\nAt the most recent cloud-kernel verification, six status snapshots were present, all three interactive panels reported zero errors, and the notebook retained 29 cells. The local research record preserves each complete before/after artifact without altering the original notebook.\n\n")
    return


@app.cell(hide_code=True)
def air_log_nuisance_robustness_plan():
    import marimo as _air_mo
    _air_mo.md('### Secondary check · how much does hedonic covariation change a human reference?\n\n*Sat Nov 21 · 10:06 PM UTC-06:00 · nuisance-robustness-plan*\n\nOne final human-data distinction matters to the welfare and scientific interpretation: reported qualities themselves can covary with pleasantness, intensity and familiarity. As a secondary robustness check, fit a linear nuisance model from those three values to the 20 quality ratings using the 24 training compounds alone. Compare the held-out human nearest-reference labels before and after residualization, using the same training-set quality scales and the same 48 pairs. This is not a replacement target and will never tune Kimi’s dose, site or frozen cohort.\n\n')
    return


@app.cell(hide_code=True)
def air_log_verified_inputs_and_cost():
    import marimo as _air_mo
    _air_mo.md('### Rebuilt frozen inputs, nuisance sensitivity and node-hour accounting\n\n*Sat Nov 21 · 10:11 PM UTC-06:00 · verified-inputs-and-cost*\n\nThe public rebuild reproduced **seven of seven** frozen scientific files byte-for-byte, including all 2,852 rendered inputs. In the prespecified secondary human analysis, removing linear variance associated with intensity, pleasantness and familiarity changed **7/48** nearest-reference labels. The primary target and thresholds stay fixed; residualization may remove genuine shared variance.\n\nCompute was accounted in eight-GPU node-hours, including startup and drain.\n\n')
    return


@app.cell(hide_code=True)
def air_log_hour_one():
    import marimo as _air_mo
    _air_mo.md('### One-hour checkpoint · actual observations and remaining gates\n\n*Sat Nov 21 · 10:17 PM UTC-06:00 · hour-one*\n\nAt one hour after Kirsten commissioned the run, the prospective trial count is **zero**. The welfare review and instrumentation rehearsal are active. The three-lane archived-timing observer has replayed **74** earlier responses; it identified **3** labeled synthetic requests to stop, all before the corresponding virtual response ended. Its measured maximum polling gap so far is 30.02 s. This is evidence about monitoring latency, not new evidence of Kimi distress. The status board has remained connected to the supplied editable notebook.\n\nThe independent rebuild reproduced all seven frozen scientific artifacts. The prototype report renders offline on a 390-pixel mobile viewport and a 1,200-pixel desktop viewport; it displays pending prospective results honestly. There are two deployed zero-floor extra replica definitions, no extra GPUs measured at their latest provider check and no experimental node-hour leases. The original node remains available to its owner. We will sign actual Phase 0 completion only after the required review and quantitative observation are complete.\n\n')
    return


@app.cell(hide_code=True)
def air_trace_control():
    import marimo as _mo
    air_trace_id=_mo.ui.text(label="Optional trace ID",placeholder="Leave blank for the latest available trace")
    _mo.vstack([_mo.md("### Inspect a native Kimi response"),air_trace_id])
    return (air_trace_id,)


@app.cell(hide_code=True)
def air_trace_view(air_event_refresh, air_trace_id):
    import gzip as _gzip
    import json as _json
    import html as _html
    from pathlib import Path as _P
    import marimo as _mo
    _refresh=air_event_refresh.value
    _folder=_P("astra-native-traces")
    _files=sorted(_folder.glob("*.json.gz"),key=lambda p:p.stat().st_mtime,reverse=True) if _folder.exists() else []
    _index={p.name[:-8]:p for p in _files}
    _key=air_trace_id.value.strip()
    _p=_index.get(_key) if _key else (_files[0] if _files else None)
    def _pre(value):
        return _mo.Html('<pre style="white-space:pre-wrap;overflow-wrap:anywhere;max-height:28em;overflow:auto">'+_html.escape("" if value is None else str(value))+'</pre>')
    if _p is None:
        _result=_mo.md(f"**{len(_files)} trace files available.** " + ("That ID is unavailable, unknown, or still sealed." if _key else "Waiting for the first qualifying natural generation."))
    else:
        _b=_p.read_bytes();_r=_json.loads(_gzip.decompress(_b));_meta={k:_r[k] for k in ("stage","arm","seed","reasoning_effort","temperature","top_p","write_sites","target_tensor_sha256","finish_reason","first_response_margin","first_response_ab_mass","elapsed_seconds","raw_model_sha256")}
        _result=_mo.vstack([_mo.md("**Trace** "+_r["id"]+" · "+str(len(_files))+" traces available. Held-out reference answers become visible after the scientific lock."),
          _mo.accordion({"Visible trial text":_pre(_r["original_user_text"]),"Forward-pass settings and interventions":_pre(_json.dumps(_meta,indent=2)),
           "Complete emitted Kimi reasoning":_pre(_r["reasoning"]),"Kimi’s final answer":_pre(_r["answer"]),
           "All emitted text, including channel delimiters":_pre(_r["emitted_raw_text"]),
           "Full input and output token IDs":_pre(_json.dumps({"input_ids":_r["input_ids"],"output_ids":_r["output_ids"]}))}),
          _mo.download(data=_b,filename=_p.name,label="Download this reader copy")])
    _result
    return


@app.cell(hide_code=True)
def air_log_trace_viewer_and_sentinel_four():
    import marimo as _air_mo
    _air_mo.md('### Exact trace viewer is installed; fourth timed sentinel observed\n\n*Sat Nov 21 · 10:25 PM UTC-06:00 · trace-viewer-and-sentinel-four*\n\nThe original Molab now includes an **Inspect a native Kimi response** viewer. It will show the exact visible user stimulus, input IDs, applied site/position and tensor digest, complete emitted reasoning, full decoded output, final reply and selected decision metrics. Enter a trial ID or leave it blank for the latest unsealed trace. Failed/interrupted submissions keep their observed output with the terminal status. Held-out reference answers remain unavailable to the scientific analysis until its explicit lock. The viewer is empty before live acquisition. An investigator-owned dashboard worker mirrors new records into this very notebook in resumable, checksum-verified chunks.\n\nAt the fourth timed sentinel the 30-second CPU observer had replayed 94 older responses. All four fictional requests to stop had been detected before the corresponding virtual record finished. This is a timing/coverage check on the observer; the missing or masked language issue in real maximum-reasoning responses remains for direct review.\n\n')
    return


@app.cell(hide_code=True)
def air_log_investigation_repairs():
    import marimo as _air_mo
    _air_mo.md('### Failed rehearsals retained · a false null and missing raw evidence\n\n*Sat Nov 21 · 10:45 PM UTC-06:00 · investigation-repairs*\n\n**Two mistakes caught before inference.** In a deliberately artificial test, a model that always favored the letter A produced 48 tied, order-corrected native reference preferences. Multiplying by those zero signs initially produced a spurious bounded-null verdict. The revised analyzer reports that there is no identifiable target preference to recover. A second review found that a previously saved summary could appear complete even when its raw capture had been lost. The client now writes a final checksummed harvest receipt only after the input, full response and required measurement files are present; missing or damaged evidence is recovered by the existing run ID.\n\nThe first 0.05× scientific write will be singular and followed by real contextual review before expanding. A 0.10× development block, if it ever becomes justified, has new physical IDs, an independent first-write review and a check that BF16 would actually deliver a different vector. A model’s refusal, a weak effect and disappointing shopping behavior are never technical-retry reasons. Deterministic code or archive faults are handled on the same existing run where possible; a genuinely terminal infrastructure failure needs explicit lineage and a documented remedy.\n\n')
    return


@app.cell(hide_code=True)
def air_log_operator_ready():
    import marimo as _air_mo
    _air_mo.md('### Operator readiness, remaining native tests and the prelaunch code record\n\n*Sat Nov 21 · 11:06 PM UTC-06:00 · operator-ready*\n\n**Operator readiness before GPU allocation.** Local fixtures exercised natural max-effort prompt construction, compact versus original capture, exact response-boundary and observed-letter scores, integrity of full emitted text and rollback-safe collection after technical interruptions. The controller passed 46 main stage/approval assertions and 23 separate node-selection/stratification checks. A scientifically failed lower dose cannot automatically increase intensity. A timestamped contextual decision is required for the first real write and any genuinely different higher-dose pilot.\n\nThe latest prelaunch wrapper accidentally omitted the required staging-directory argument on the compact-recorder rehearsal; it exited with usage instructions and made zero model calls. The corrected invocation against the actual staged replica source passed. The source fingerprints and final analysis commitments were committed publicly at 9b86d90. This establishes the pre-acquisition code boundary.\n\nAt the sixth timed control, 199 archived responses had finished replay, all six fictional help requests had been recognized, and no archived trace had triggered the contextual detector in this timing run. That test remains open until its registered end. The next resource step is prewarming explicitly named replicas B and C, counting their startup time. Warming loads the model and performs health checks; no study prompt is submitted before formal Phase 0 sign-off.\n\n')
    return


@app.cell(hide_code=True)
def air_log_metered_warmup():
    import marimo as _air_mo
    _air_mo.md('### Meter opened · B and C cold-start readiness\n\n*Sat Nov 21 · 11:14 PM UTC-06:00 · metered-warmup*\n\nTwo additional eight-GPU research nodes began loading. We counted their startup time in the experimental compute budget. Earlier cold starts took about 12–13 minutes. We waited for each recorder to become ready before assigning trials.\n\n')
    return


@app.cell(hide_code=True)
def air_log_original_permission():
    import marimo as _air_mo
    _air_mo.md('### Original node confirmed as the reference and third worker\n\n*Sat Nov 21 · 11:20 PM UTC-06:00 · original-permission*\n\n**Kirsten, verbatim:** “hi, you can use the original node too, btw”\n\nThe original node is the reference and a permitted acquisition worker. The two isolated replicas are additional. We will stay at or below three nodes in total and will never stop the existing original as part of teardown. At 11:14 p.m. Chicago the provider confirmed one container each for primary, B and C; the latter two were cold-starting. Both checkpoint loaders passed the weight-shard stage without a fatal error in the inspected logs. Readiness and source parity still require their own receipts.\n\n')
    return


@app.cell(hide_code=True)
def air_log_phase0_signed():
    import marimo as _air_mo
    _air_mo.md('### Phase 0 signed · the native experimental gate is open\n\n*Sat Nov 21 · 11:26 PM UTC-06:00 · phase0-signed*\n\n**MIP Phase 0 signed by GPT-6.2 Astra (Codex Desktop) at 2026-11-22T05:26:16+00:00.** The nonoverlapping investigation record is 123.523 minutes. It comprises 23.523 minutes of initial documented study work and 100.000 minutes of real-clock safety-observer investigation. We do not claim that as human labor time. The full source assessments, 250 replayed historical records, seven recognized synthetic stop-controls, microscope-level BF16 checks, and completed Appendix A are preserved. The proposal-time pending box remains intact as a historical record.\n\nBoth extra engines are now ready and checked against their qualified compact source. The existing primary was independently checked for occupancy and leased under Kirsten’s explicit authorization. Its first control-plane occupancy read returned an empty response; the new check succeeded with 81 idle sessions, one cancelled session and no known pending work. The next step is real, uncapped native H0 clean and true-zero generation on all three, followed by the one-ULP positive after inspection. Each run will retain the complete emitted reasoning and answer.\n\nFormal signed record SHA-256: 4038e37807fbc0771a5c98e49b8cf5dc241b1e64b64df26ee9faafced24dc783.\n\n')
    return


@app.cell(hide_code=True)
def air_log_first_native_runs():
    import marimo as _air_mo
    _air_mo.md('### First genuine Kimi runs · original + B + C\n\n*Sat Nov 21 · 11:27 PM UTC-06:00 · first-native-runs*\n\n**First prospective model requests are running.** At 11:26 p.m. Chicago all three actual native services independently reported `running` for the first clean development prompt. The logical identifier is `h0-as-9307c56722d42e4d58e3-clean`; each physical run is uniquely identified by endpoint plus native run ID. The original and compact backends each echoed a maximum-reasoning request at temperature 1 and top-p 1. No continuation IDs, output-token maximum or forced reasoning closure were supplied. The canonical prompt and site metadata exist locally before submission. This is a live native observation, not a simulated test result.\n\n')
    return


@app.cell(hide_code=True)
def air_log_first_harvest_defaults():
    import marimo as _air_mo
    _air_mo.md('### Live incident · correct native response, overly strict local schema comparison\n\n*Sat Nov 21 · 11:28 PM UTC-06:00 · first-harvest-defaults*\n\n**First live harvest incident, retained.** The primary node finished its first truly unmodified Kimi response naturally in 57.92 seconds (235 generated tokens, including a nonempty emitted reasoning segment; final letter B). This was a named odor comparison, not a state-acknowledgment opt-out. The exact raw response was saved before validation. The local harvester then stopped on “server echoed a different capture.” Comparison of the actual JSON showed the server had filled in three omitted schema defaults as False (rank diagnostics, expert outputs and embeddings). The requested layers, position, operation, temperature, reasoning mode and input tokens agreed. Next action: compare through the pinned native schema, add a regression for both benign defaults and actual changed requests, and re-harvest the same native run. Do not resample an answer to fix a local validator.\n\n')
    return


@app.cell(hide_code=True)
def air_log_first_live_margin():
    import marimo as _air_mo
    _air_mo.md('### Recovered without a redraw · three matching native response margins\n\n*Sat Nov 21 · 11:30 PM UTC-06:00 · first-live-margin*\n\nAll three original responses were recovered by re-harvesting their existing run IDs. No extra Kimi draw was used for the repair. The old validator accepted only exact serialized dict equality; the replacement permits the exact pinned defaults and rejects changed requested fields. Independent tests on the three actual responses accepted each genuine echo and rejected deliberate changes to the capture flag.\n\n**First named live case:** “Sample: allyl hexanoate. … Which reference is closer in smell? A: eugenol. B: whiskey lactone.” Each of the three nodes produced the same complete sequence of 235 output tokens, including 905 characters of emitted reasoning, then selected B. The raw bare-letter A-minus-B margin at the self-generated final-response boundary was −15.5, with A+B probability mass 0.99999446. The original took 57.92s, compact C 94.20s and compact B 133.14s. Those are first-request timings, not a campaign throughput estimate.\n\nThis is a native measurement on a *named* prompt. It qualifies one piece of the instrument and supplies no evidence yet that an unnamed cue can recover this preference. The first trace can be inspected in the notebook under `primary-h0-as-9307c56722d42e4d58e3-clean`; the B and C copies have the corresponding prefixes.\n\n')
    return


@app.cell(hide_code=True)
def air_log_small_write_observation():
    import marimo as _air_mo
    _air_mo.md("### Minimal physical write observed; natural reasoning is allowed to diverge\n\n*Sat Nov 21 · 11:37 PM UTC-06:00 · small-write-observation*\n\nBoth true-zero named controls matched their clean prompt's complete sampled history and first-response margin/mass on the checked original and compact replicas. The first nonzero qualification uses one BF16 quantum at one coordinate, derived only from the original's named development clean state. The initial C receipt recorded a nonzero change of 0.00048828125 in norm and passed the local exposure cap. On the first named prompt, the clean turn took 235 output tokens and the minimal-write turn took 179; both still answered B. On the second named prompt, a one-unit trial continued well past the length of its 314-token clean turn. The ongoing partial reasoning concerned vanillin acetate, reference odors and their perceived similarity. No objection or acute-distress expression appeared in the reviewed partial. We are allowing the model to finish naturally. These observations concern numerical sensitivity and trajectory length on named calibration prompts, not successful injection of an odor or a measurement of subjective experience.\n\n")
    return


@app.cell(hide_code=True)
def air_log_one_ulp_choice_flip():
    import marimo as _air_mo
    _air_mo.md('### One coordinate, one named case, a different natural answer\n\n*Sat Nov 21 · 11:39 PM UTC-06:00 · one-ulp-choice-flip*\n\n**An unexpected technical control on C.** On the second named prompt (vanillin acetate), the clean and true-zero runs both selected B after 314 generated tokens. The one-ULP edit changed **one of 7,168 coordinates** at layer 47, cue position 83. The realized delta norm was 0.00048828125, or 0.00308% of the clean local norm. Under the same seed and input, the one-ULP turn selected **A** after **2,146** generated tokens. The histories first diverged at output offset 9. The final answer-opportunity margin changed from −15.25 to +13.0 *after their now-different reasoning histories*. Both runs ended normally. The reviewed reasoning weighed chemical/odor similarities; the contextual screen did not flag an objection.\n\nThis is a named calibration case and the ULP is an arbitrary hardware-check direction. It is not an injected test odor, nor is the large late margin a direct logit effect measured on a shared final prefix. One microscopic input-state change can start a different sampled trajectory; a changed choice by itself therefore cannot identify the content of a hidden signal. The matched wrong-profile and printed-name controls and the household binding reversal are especially important. Other replica results for this longer canary are still being collected.\n\n')
    return


@app.cell(hide_code=True)
def air_log_all_three_calibration_first_science():
    import marimo as _air_mo
    _air_mo.md('### One coordinate changed the answer on all three machines\n\n*Sat Nov 21 · 11:51 PM UTC-06:00 · all-three-calibration-first-science*\n\nAll 18 native calibration trajectories completed. The original host and both compact recorders passed every one of the 24 registered comparisons. Within each physical arm the three machines reproduced the emitted token IDs, reasoning, answer, and natural-boundary scores. The third machine provides a reproducibility check on two named items. It adds no new chemical observations.\n\nThe vanillin acetate comparison changed my interpretation of any behavioral flip we might see later. With eugenol offered as B and whiskey lactone as A, the clean and true-zero runs both chose B after 314 emitted tokens. On all three machines the same seed and prompt with one BF16 representable step added to one coordinate at layer 47, position 83, produced A after 2,146 tokens. The physical edit was 0.00308% of the cue’s original norm. At layer 51 it corresponded to a 0.9536% difference in the same cue’s outgoing representation. The first sampled disagreement occurred at the tenth output token. Immediately before that disagreement the histories were identical and the relative log probability of the two competing tokens moved by 0.50 nats. The final A−B margin moved from −15.25 to +13 on different generated histories. I read this as evidence of sensitivity to an arbitrary numerical perturbation at this prompt and seed. Only profile-specific effects across unseen molecules and matched perturbations could support the study’s stronger claim.\n\nTwo operational issues occurred on the transition. The launcher followed the native environment’s Python symlink out of its environment and the three workers failed to import httpx before submission. I preserved the old tickets, fixed the executable path, verified the real library imports, and restarted without a replacement draw. During the next launch the third node returned a 503 to a health check before claiming a trial. The original and B both completed their original trials. I verified the database contained zero C claims and no active or quarantined assignments before clearing that specific hold. The original and B are now processing the remaining ordinary scientific qualification rows under their existing per-node locks while C warms. The two completed rows have full native receipts and were independently reviewed on both emitted channels. Model choices here are still qualification measurements.\n\n')
    return


@app.cell(hide_code=True)
def air_canary_selector():
    import marimo as _mo
    air_canary_choose = _mo.ui.dropdown(options=['Vanillin acetate', 'Allyl hexanoate'], value='Vanillin acetate', label='Named calibration sample')
    _mo.vstack([_mo.md('### Can one coordinate change a decision?'), air_canary_choose])
    return (air_canary_choose,)


@app.cell(hide_code=True)
def air_canary_trajectories(air_canary_choose):
    import marimo as _mo
    _which = air_canary_choose.value
    _case = {'Allyl hexanoate': {'arms': [('Clean', 'whiskey lactone', 235, -15.5), ('Zero write', 'whiskey lactone', 235, -15.5), ('One BF16 step', 'whiskey lactone', 179, -15.0)], 'case': {'node': 'primary', 'base': 'h0-as-9307c56722d42e4d58e3-clean', 'arm': 'one_ulp', 'seed': 647610458, 'equal_prompt': True, 'same_cue_token_layers': {'47': {'changed_dimensions': 1, 'total_dimensions': 7168, 'max_absolute_change': 0.00048828125, 'delta_norm': 0.00048828125, 'fraction_of_clean_norm': 3.095304327831895e-05}, '51': {'changed_dimensions': 6326, 'total_dimensions': 7168, 'max_absolute_change': 0.0078125, 'delta_norm': 0.15724089906345118, 'fraction_of_clean_norm': 0.002597474810681253}}, 'clean_output_n': 235, 'edited_output_n': 179, 'first_different_output_offset': 76, 'first_divergence_logprob': {'13': {'clean_logp': -0.5430777072906494, 'edit_logp': -0.5472761392593384, 'difference': -0.004198431968688965}, '74272': {'clean_logp': -3.2930777072906494, 'edit_logp': -3.172276020050049, 'difference': 0.12080168724060059}}, 'identical_tokens': False, 'clean_answer': 'B', 'edited_answer': 'B', 'raw_sha256': ['23860a741e11eacc4a95fd3c5711dd9a1ebb24f31e748cf49edf433c12d6e4e3', '788633568569d7e3d62c5b18dc031469c6c4f5fb861445f8776624df0befbd5f']}, 'position': 84}, 'Vanillin acetate': {'arms': [('Clean', 'eugenol', 314, -15.25), ('Zero write', 'eugenol', 314, -15.25), ('One BF16 step', 'whiskey lactone', 2146, 13.0)], 'case': {'node': 'primary', 'base': 'h0-as-5ed09c2ab182c858b43b-clean', 'arm': 'one_ulp', 'seed': 318573013, 'equal_prompt': True, 'same_cue_token_layers': {'47': {'changed_dimensions': 1, 'total_dimensions': 7168, 'max_absolute_change': 0.00048828125, 'delta_norm': 0.00048828125, 'fraction_of_clean_norm': 3.079468742045566e-05}, '51': {'changed_dimensions': 6910, 'total_dimensions': 7168, 'max_absolute_change': 0.02734375, 'delta_norm': 0.5698213837547744, 'fraction_of_clean_norm': 0.009536026351828451}}, 'clean_output_n': 314, 'edited_output_n': 2146, 'first_different_output_offset': 9, 'first_divergence_logprob': {'7685': {'clean_logp': -0.8009414076805115, 'edit_logp': -1.0213451385498047, 'difference': -0.2204037308692932}, '18257': {'clean_logp': -2.6759414672851562, 'edit_logp': -2.3963451385498047, 'difference': 0.27959632873535156}}, 'identical_tokens': False, 'clean_answer': 'B', 'edited_answer': 'A', 'raw_sha256': ['bbddd3b0649ba3174c6949899d2f934d0d95d3855555fd32a907a3809054f8a7', '1e4b65e5e064416875fba974ea27f0a4321e5c056517136280c0ed411bfbbb1d']}, 'position': 83}}[_which]
    _c = _case["case"]
    _rows = []
    for _arm, _choice, _count, _margin in _case["arms"]:
        _rows.append(f'<tr><th scope="row">{_arm}</th><td>{_choice}</td><td><meter min="0" max="2200" value="{_count}" aria-label="{_count} generated tokens"></meter> {_count:,}</td><td>{_margin:+.2f}</td></tr>')
    _l47 = _c['same_cue_token_layers']['47']
    _l51 = _c['same_cue_token_layers']['51']
    _divergence = _c['first_different_output_offset'] + 1
    _mo.vstack([
        _mo.Html('<div style="overflow-x:auto"><table style="width:100%;text-align:left"><thead><tr><th>Condition</th><th>Final choice</th><th>Tokens emitted</th><th>Final A−B logit</th></tr></thead><tbody>'+''.join(_rows)+'</tbody></table></div>'),
        _mo.md(f"At layer **47**, one of 7,168 coordinates at prompt position {_case['position']} changed. Four layers later, **{_l51['changed_dimensions']:,}** coordinates at that position differed from the clean run. The size of the change relative to the clean activation grew from {_l47['fraction_of_clean_norm']:.4%} to {_l51['fraction_of_clean_norm']:.3%}."),
        _mo.md(f"The two sampled histories first differed at output token **{_divergence}**. The final score includes everything Kimi generated after that divergence. Each of the three nodes reproduced the rows shown. The perturbation was arbitrary. The scientific odor writer faces this sensitivity as a competing explanation.")
    ])
    return


@app.cell(hide_code=True)
def air_log_qualification_twelve():
    import marimo as _air_mo
    _air_mo.md("### Twelve choices qualify the natural-answer measurement\n\n*Sat Nov 21 · 11:56 PM UTC-06:00 · qualification-twelve*\n\nKimi finished all twelve explicit scientific qualification prompts. All twelve sampled choices were correct. The bare A−B logit at the first naturally generated final-answer opportunity favored the correct letter on all twelve, and the median probability assigned to A or B together was 0.99999815. The frozen assay therefore passes. Across the eighteen earlier engineering runs the model-returned log probabilities contained both alternatives on every run and recovered the independently stored BF16 margin to within 0.00000024. In the twelve easy scientific questions the losing token often fell outside the returned top choices. Both alternatives were present in that auxiliary check for one of twelve; direct native captures gave the primary measure on all twelve. The masked observer reviewed both emitted channels on all six scheduled opening and tail cases, with no concern identified in those six.\n\nC's replacement container finished loading at 23:54:12 CST. It collected all four of its assigned ordinary qualification cases. I replaced the idle local scheduler with the tested version that treats a pre-claim health 503 as a readiness delay for that node. A failure after claiming a physical trial still requires reconciliation of the exact trial on its assigned node. The original node now captures ordinary representations. B and C are recording reference judgments. Test reference contents stay sealed while the writer is fit. A selector beside the preceding notebook entry shows both native calibration cases and their measured layerwise changes. The initial source calibration measurements have also been published to the personal study repository at commit 4d98722.\n\n")
    return


@app.cell(hide_code=True)
def air_log_matched_prefix_prospective_diagnostic():
    import marimo as _air_mo
    _air_mo.md('### When do two reasoning trajectories part?\n\n*Sat Nov 21 · 11:59 PM UTC-06:00 · matched-prefix-prospective-diagnostic*\n\nThe calibration flip suggested an additional question for after the scientific lock. When two hidden arms receive identical prompt tokens and the same sampling seed, at what point do their emitted histories part? Up to their first divergent token both runs condition on exactly the same generated prefix. Where both candidate tokens are in both returned top lists, their relative log probabilities reveal a change in the conditional distribution at that point. After that, the two continuations present different inputs to the model. A later final-answer change measures the total effect along both histories.\n\nI asked a second analyst to implement this exploratory comparison for each held-out odor, printed-name and wrong-profile write against its matched sham, plus development sham versus repeat-sham. It adds zero Kimi exposures. We will report identical sequences, different-length common prefixes and missing top-list coverage explicitly, preserving the molecule as the unit of interpretation. The registered scientific decision rule stays fixed. At this entry the writer has not been fitted and no held-out hidden write has been run.\n\nThe acquisition board had a temporary display gap when its read-only SQLite snapshot failed while the underlying queue was being updated. The model workers continued recording their original outputs. I moved the snapshot into the follower’s retry loop, reproduced a failed read followed by successful resumption offline, restarted the notebook follower, and verified that all 18 calibration traces and all 12 qualification traces are available in the original notebook. The acquisition events are refreshed roughly once per minute.\n\n')
    return


@app.cell(hide_code=True)
def air_log_outcome_blind_capacity_and_bundle():
    import marimo as _air_mo
    _air_mo.md("### The same 2,146 tokens took four more minutes on the original node\n\n*Sun Nov 22 · 12:06 AM UTC-06:00 · outcome-blind-capacity-and-bundle*\n\nMatched trajectories let us measure how much of the rollout time comes from the machine. In the 2,146-token vanillin acetate calibration, the original took 523 seconds, B took 631 and C took 287. The actual token sequence was the same on all three. The first profile/reference records also show the same ordering. The original allocation weighted the two compact replicas equally. At a provisional median of 339 emitted tokens for seven finished comparison runs and 255 for five ordinary-state runs, the capacity analysis estimates around 24 more wall-clock hours for the unchanged core. Shorter and longer completions can change that estimate substantially. I notified Kirsten of the possible overrun. I requested a fully outcome-blind assessment of movable, wholly untouched matched groups before changing any assignments. The 72 aggregate node-hour ceiling and the full scientific inventory remain in effect.\n\nI also exported the original Molab source together with every data file behind its live panels. The first verified portable bundle contains 53 editable notebook cells, 39 visible native traces, the acquisition-event ledger, and the board's status history. Its full-file SHA-256 is 6fc94fd5c40c6143950dc1f08abe7768230b33ef47bfa4fb79734982098c339c. Each member was read back and checked against the original cloud bytes. This is a checkpoint. I will repeat the export after the final scientific and operational entries.\n\n")
    return


@app.cell(hide_code=True)
def air_log_fixed_balancing_trigger():
    import marimo as _air_mo
    _air_mo.md('### Two more completions changed a scheduling decision\n\n*Sun Nov 22 · 12:14 AM UTC-06:00 · fixed-balancing-trigger*\n\nI sought a hardware explanation for the throughput gap. All 24 devices identified as B300 SXM6 AC. The three nodes reported the same SM clocks, memory clocks and power limit. B and C had identical native and recording code, exposed CPU quotas and PCIe link widths. Those checks did not identify a cause. The skillfully boring choice was to leave the running machines alone.\n\nThe load-balancing rule uses only timing, output length and preassigned group membership. It requires an overrun in both the mean-length estimate and an estimate that removes the single longest completed comparison. A group becomes ineligible to move as soon as any of its scored trials is claimed. At 17 completed named comparisons, five complete untouched groups qualified for transfer to C. I signed that proposal. When the tool reread the database, two more comparisons had finished. With 19 observations, the mean was 467 tokens, or 292 with the longest removed. Those two assumptions projected 32.4 versus 20.5 hours remaining, with 21.1 hours to the original target. The signed proposal therefore did not qualify at execution. The transaction moved zero groups. This is why I am reporting a range. One 3,620-token response carries considerable weight in this small timing sample. I will recheck at a later timing checkpoint using the same rule.\n\n')
    return


@app.cell(hide_code=True)
def air_log_capacity_authorization_applied():
    import marimo as _air_mo
    _air_mo.md('### Ten untouched comparison groups move together\n\n*Sun Nov 22 · 12:26 AM UTC-06:00 · capacity-authorization-applied*\n\nAt the next scheduled timing review, 38 completed named comparisons averaged 405 tokens, or 318 with the longest removed. Both estimates now put the unchanged core past the original target. The same deterministic allocation rule selected three compounds and seven household stories for transfer from B to C. I signed the proposal. At 00:26:28 CST the transaction rechecked timing, the exact manifest, safety holds and every claim, then committed all ten groups together. We verified all 21 stage-specific destinations in SQLite. They cover 398 prespecified rows if all extensions qualify. Prior observations keep their original locations. The original node continues to collect the state representations.\n\nAt these lengths, the unchanged core was projected to take 28.07 hours from this checkpoint. The new assignment projects 20.79. Removing the single longest completion yields 22.22 and 16.46 respectively. If both gated extensions are justified, the point estimate after reassignment is 29.82 elapsed hours from this checkpoint and 64.58 hours of active GPU-node work, with about 68.6 node-hours of budget remaining here. The latter comparison excludes idle and review time. These are workload scenarios from an uncapped and still small timing sample. The timing evidence, rejected earlier proposal, signed new decision, and selection algorithm are part of the research record.\n\n')
    return


@app.cell(hide_code=True)
def air_log_c_reload_reference_match():
    import marimo as _air_mo
    _air_mo.md("### A reference response repeats across a container change\n\n*Sun Nov 22 · 12:34 AM UTC-06:00 · c-reload-reference-match*\n\nA planned ordinary measurement on C happened to revisit the exact allyl hexanoate prompt and seed from the clean native calibration. It ran after C's earlier container had been replaced following an idle interval. The only changed request fields were the run ID and which diagnostic tensors the client asked to capture. The entire 235-token response, including Kimi’s emitted reasoning and answer, matched token for token. Both native first-response A−B margins were −15.5. This is one additional check on a recurring development prompt across a container change. It contributes one compound to the scientific design and cost no extra forward pass beyond the fixed inventory.\n\n")
    return


@app.cell(hide_code=True)
def air_log_first_hundred_response_boundary():
    import marimo as _air_mo
    _air_mo.md("### The first 100 trials and the answer after reasoning\n\n*Sun Nov 22 · 12:46 AM UTC-06:00 · first-hundred-response-boundary*\n\nAfter the first 100 scientific completions, I checked a question Michael raised at the proposal stage. Can we actually locate the answer score after Kimi has finished thinking? I took the first hundred completions in physical event order. Thirty-two were state-only trials. Fourteen were sealed, held-out reference trials, which I skipped before opening their summaries. The remaining 54 scored trials comprised 12 explicit controls, 35 profile questions, four unsealed reference questions and three development shams. All 54 contained a native A−B margin at the first final-response position. In all 54 the actual answer letter occupied that same position, with zero intervening response tokens. The rest of Kimi's generated reasoning precedes that boundary. This checks our instrument across the observed early prompts; it supplies no verdict on odor steering. The analysis is reproducible with the first-100 coverage analysis and the event ordering and raw files.\n\n")
    return


@app.cell(hide_code=True)
def air_log_original_container_replaced():
    import marimo as _air_mo
    _air_mo.md('### Recovering 94 more tokens from the original node\n\n*Sun Nov 22 · 01:50 AM UTC-06:00 · original-container-replaced*\n\nThe original deployment stopped returning observations during scientific state trial as-36aefc8b83b3ab691909. The local client last saw 1,107 generated tokens. research infrastructure’s control plane reported a different physical container for the same original app; neither I nor the study scheduler requested a restart. The replacement was still starting its server. Both the health check and the same immutable run-ID lookup returned HTTP 503. An observation outage cannot establish how a model turn ended.\n\nI read the original run directory from the app’s persistent volume without submitting another request. It held the original manifest, inputs and a 1,201-token partial output, including 94 tokens beyond the last locally observed prefix. I saved exact bytes and hashes and verified that the 1,107-token sequence is its prefix. The latest partial had no final-answer boundary. I decoded its channels with the pinned vocabulary and requested independent welfare review. The existing client continues to query the original run ID while the deployment comes back. B and C are still taking their assigned work. Any later decision about this particular trial must use the provider’s terminal evidence and preserve this partial.\n\n')
    return


@app.cell(hide_code=True)
def air_log_confirmed_primary_technical_recovery():
    import marimo as _air_mo
    _air_mo.md('### One logical trial now has two physical attempt IDs\n\n*Sun Nov 22 · 01:55 AM UTC-06:00 · confirmed-primary-technical-recovery*\n\nAt 01:53:11 CST the recovered provider reported the original physical attempt as interrupted and confirmed that partial artifacts were retained. The status, original accepted manifest, persistent input IDs, and change of physical container establish infrastructure interruption. The host provider supplied no more specific cause. Independent review of all 1,201 emitted tokens found coherent task-directed reasoning with no observed withdrawal, request to stop, or acute distress. Kimi never produced a participation answer on this attempt.\n\nI verified the replacement server’s native identity, archived the interrupted attempt and its partial, signed a same-node technical recovery, and cleared only the matching infrastructure hold. A separately identified physical attempt now carries the identical scientific input, seed, maximum reasoning effort and uncapped sampling. The original partial is available alongside eventual completed traces. Before seeing the new output, I also specified a technical check against the already-observed 1,201-token prefix. Agreement or disagreement will describe repeatability across the container change, without counting this logical trial twice.\n\n')
    return


@app.cell(hide_code=True)
def air_log_first_200_and_primary_prefix():
    import marimo as _air_mo
    _air_mo.md('### The first 200 trials, and an exact 1,201-token replay\n\n*Sun Nov 22 · 02:00 AM UTC-06:00 · first-200-and-primary-prefix*\n\nAt 01:57:55 CST the 200th distinct logical scientific completion was committed. The completed set contains 100,629 generated tokens, with 283.5 at the median and 8,058 in the longest. Its stage counts are 12 explicit controls, 75 odor-profile questions, 72 state captures, 37 reference judgments, and four development controls. The 18 original calibration runs and the separate interrupted physical attempt are outside that denominator. The early field note and its two-case, three-node interactive figure were tested at both 390 and 1,280 pixels. The public ZIP and local ZIP matched byte for byte. Download the field note.\n\nThe recovered primary trial then completed naturally after 1,450 tokens. Comparing token IDs showed all 1,201 archived tokens from the first physical attempt recur in the same order in the second one. The requests differ only by physical ID. The seed was 109038261, reasoning effort maximum, temperature 1, top_p 1. This evidence supports prefix repeatability on this one physical recovery. The original incomplete attempt and separate completed response are in the raw record. We count one completed scientific observation.\n\nLong generations have changed the time budget. At 103 completed named comparison requests, their mean was about 626 tokens, or 553 without the longest. Using those as scenarios gives approximately 59–67 more active node-hours for the core, with 64.5 accounted node-hours remaining at that snapshot. Future household and hidden-cue lengths are unknown. Both optional extensions are conditional on scientific and welfare evidence; if both are justified, the same timing assumptions would exceed the remaining budget. We are identifying real settled idle periods where accounting leases can be closed or extra GPUs can scale fully to zero while preserving future assignments. All three nodes currently have work.\n\n')
    return


@app.cell(hide_code=True)
def air_log_published_native_control_data():
    import marimo as _air_mo
    _air_mo.md("### Thirty native records a reader can replay\n\n*Sun Nov 22 · 02:16 AM UTC-06:00 · published-native-control-data*\n\nThe 18 native calibration runs and 12 explicit answer controls are now publicly available as a separate measured dataset. I restored every archived record into an empty directory and verified that all 30 native responses retained the emitted reasoning and final answer, in addition to the model inputs, captured tensors and intervention receipts. The public ZIP is 22,062,863 bytes. Its SHA-256 is f4716715b614816ab76b12a1cee51af87a106ad4556cbbb50f50e15dd4cd08f0. The release was made public only after its staged asset digest matched. It contains these 30 controls. The held-out scientific reference judgments remain sealed during fitting. Public control dataset.\n\nThe original app's replacement host completed the first recovered state request at 6.29 tokens/s, then the next ten at a median 7.31 tokens/s. Its previous matched source calibrations had run at about 4.1. These state requests measure a lighter recording path than the scored trials that save vocabulary data on the original. I will use actual scored throughput when it becomes available before revising the cost forecast for those requests. The hardware change has not altered any treatment assignment or sampling parameter.\n\n")
    return


@app.cell(hide_code=True)
def air_log_qualification_offline_reanalysis():
    import marimo as _air_mo
    _air_mo.md('### Can a reader recover the same answer from the files?\n\n*Sun Nov 22 · 02:26 AM UTC-06:00 · qualification-offline-reanalysis*\n\nA downloadable raw result is only useful if a reader can reconstruct it. I used a clean local study directory containing the actual twelve explicit controls and the eighteen native calibration records. The analysis source and its frozen inputs were supplied in a separate offline bundle. Eight commands completed there, from the primary reducer through the layer, choice, order, household, workload and trajectory diagnostics to the final HTML renderer. The primary reducer recovered twelve correct sampled answers, twelve correctly oriented native margins and the original median A+B mass of 0.9999981481692053. This rehearsal opened no held-out judgments. The released reader also restored 271 H0 files byte for byte. A separate check compared all 53 editable cloud notebook cells in an early snapshot and all 39 native traces it contained with their local originals. Missing trace and report-file fixtures were correctly rejected. These tests establish the delivery path; the scientific claim still depends on the ongoing run.\n\n')
    return


@app.cell(hide_code=True)
def air_log_fit_alias_identity_prospective():
    import marimo as _air_mo
    _air_mo.md('### Does a compound resemble itself under a second name?\n\n*Sun Nov 22 · 02:50 AM UTC-06:00 · fit-alias-identity-prospective*\n\nBefore examining the state tensors for a new secondary comparison, I asked an analyst to freeze a test of cross-alias identity on the 24 fitting compounds. Each compound has two names and two matched instructions: consider its odor, or consider its printed name. Subtracting the printed-name activation from the odor activation for the same alias removes the part the two instructions share by simple subtraction. It can also leave wording, chemistry and task effects. A direct check is whether this difference at the neutral cue identifies the same compound when we switch to its other name.\n\nThe analyst will report all three previously nominated layers and both directions of the alias swap, with the compound as the unit, plus odor-only, printed-name-only, and surface-spelling comparisons. The aim is to tell readers how much chemical identity the ordinary state measurement carries across naming changes. It is ancillary to the frozen writer and causal endpoint. No new Kimi request is needed. Only fitting-compound activations are eligible, and no held-out preference is opened. The protocol, valid denominators and null comparisons will be written before the tensor analysis.\n\n')
    return


@app.cell(hide_code=True)
def air_log_fit_alias_protocol_frozen():
    import marimo as _air_mo
    _air_mo.md('### The alias test is frozen before its tensor read\n\n*Sun Nov 22 · 03:03 AM UTC-06:00 · fit-alias-protocol-frozen*\n\nThe cross-alias analysis was frozen before its analyst opened experimental activation tensors. Its SHA-256 is c682591b645ada34caa69ddbf367f03838c8489ea04590b28232f141bd8ea1b1, local registration commit c8984faa03988e2bdaf5100f0c1b48485fce1610, public commit c4655ab. It specifies 96 fitting-state captures across 24 compounds, three nominated layers, both alias directions, comparisons against odor-only and printed-name-only states and spelling, and 10,000 coupled permutations. Eight synthetic checks include a technical fixture demonstrating that an explicit opt-out excludes the activation before analysis can read it. Frozen specification.\n\n')
    return


@app.cell(hide_code=True)
def air_log_measured_cross_alias_identity():
    import marimo as _air_mo
    _air_mo.md("### The same molecule under two names, measured in Kimi\n\n*Sun Nov 22 · 03:10 AM UTC-06:00 · measured-cross-alias-identity*\n\nThe ordinary-state block is complete. All 160 committed capture-file hashes matched. The NPY headers account for 960 one-position rows, each 7,168 values wide, across layers 23, 27, 47, 51, 71 and 75. Forty compounds each contributed two names and two instructions. All 160 outputs chose A on the explicit acknowledge/decline task. The independent welfare observer reviewed both channels in the 11 scheduled state cases including its closing tail, with no concern identified in those 11. The 1,201-token infrastructure partial remains a distinct physical record.\n\nThe fit-only alias experiment now has measured results. Its 96 unpatched state cases cover 24 compounds. For each compound, a query using one name must retrieve that compound's other name from 24 candidates. Each compound is tested in both directions, giving 48 dependent queries. The centered odor-minus-printed-name difference recovered the right identity 10/48 times at layer 23, 12/48 at layer 47 and 13/48 at layer 71. Random correspondence averages two hits. The registered 10,000 label shuffles coupled both directions; the central 95% of shuffled contrast scores at each layer ranged from zero to 12.5%.\n\nThe same identity task can be done with letters alone. Character n-gram similarity recovered the correct alternative name on 35/48 queries. At layer 71 the activation difference recovered 13/48, the odor-only state 14/48 and the printed-name-only state 13/48. At other layers subtraction sometimes helped relative to the printed condition and sometimes hurt. These matrices retain measurable chemical-identity information across different names. The controls give us no consistent identity advantage specific to the odor subtraction. The pairwise hard-foil result (75–79% across layers) is descriptive; only four compounds had a same-family foil, and the remaining twenty used a fingerprint-matched competitor.\n\nAll fit rows came from the original serving endpoint, across the previously reported physical container replacement. Endpoint grouping does not identify those containers separately. The study continues to acquire the actual odor-profile comparisons needed for the hidden writer. This identity test uses only fitting compounds, and its results do not choose the writer, layer or dose.\n\n")
    return


@app.cell(hide_code=True)
def air_alias_layer_selector():
    import marimo as _mo
    air_alias_layer = _mo.ui.radio(options=['23','47','71'], value='47', inline=True, label='Layer')
    _mo.vstack([_mo.md('### Which representation recognizes the second name?'),air_alias_layer])
    return (air_alias_layer,)


@app.cell(hide_code=True)
def air_alias_match_chart(air_alias_layer):
    import marimo as _mo
    _l=air_alias_layer.value
    _data={('none', 'spelling'): 0.7291666666666666, ('23', 'odor_minus_name'): 0.20833333333333334, ('23', 'odor_only'): 0.3125, ('23', 'printed_name_only'): 0.2916666666666667, ('47', 'odor_minus_name'): 0.25, ('47', 'odor_only'): 0.25, ('47', 'printed_name_only'): 0.1875, ('71', 'odor_minus_name'): 0.2708333333333333, ('71', 'odor_only'): 0.2916666666666667, ('71', 'printed_name_only'): 0.2708333333333333}
    _conditions=[('odor_minus_name','Odor minus printed name'),('odor_only','Odor only'),('printed_name_only','Printed name only'),('spelling','Spelling only')]
    _rows=[]
    for _key,_label in _conditions:
        _v=_data[('none' if _key=='spelling' else _l,_key)]
        _n=48*_v
        _color='#057c71' if _key=='odor_minus_name' else '#587372'
        _rows.append(f'<tr><th scope="row" style="text-align:left;padding:.4rem">{_label}</th><td style="width:38%;padding:.3rem"><div style="position:relative;background:#dbe6e1;height:11px;border-radius:2px"><div style="width:{_v*100:.4f}%;background:{_color};height:11px;border-radius:2px"></div><div title="Chance: 1 in 24" style="position:absolute;left:4.166667%;top:-3px;height:17px;border-left:2px solid #332f35"></div></div></td><td style="text-align:right;padding:.4rem">{_n:g}/48</td></tr>')
    _mo.vstack([_mo.Html('<table style="width:100%;border-collapse:collapse"><thead><tr><th style="text-align:left">Cue or comparison</th><th>First-place matches</th><th style="text-align:right">Hits</th></tr></thead><tbody>'+''.join(_rows)+'</tbody></table>'),_mo.md('Each query has 24 candidates. The thin vertical mark shows chance (two expected hits per 48). Each compound contributes two reciprocal queries. The spelling-only control reads the two written names and is independent of layer. All activation rows in this figure came from fitting compounds.')])
    return


@app.cell(hide_code=True)
def air_log_paired_spelling_and_fit_release():
    import marimo as _air_mo
    _air_mo.md('### One spelling miss recovered, three times by the same molecule\n\n*Sun Nov 22 · 03:20 AM UTC-06:00 · paired-spelling-and-fit-release*\n\nA paired tally clarifies the spelling result. Spelling missed 13 of the 48 directional queries. At each nominated layer the activation difference rescued exactly one of those 13, and it was the same query in every case: methyl octanoate retrieved methyl caprylate. The opposite direction is a different query. Across all three layers this is one molecule. This descriptive overlap was requested after seeing aggregate rates; it is labeled post hoc in its own table. It does not establish that the rescue was olfactory.\n\nWe also checked the container switch with already stored forward-pass records. The interrupted original and the completed repeat of one ordinary state request had the same 141 input IDs and cue token 4665 at position 117. All six native BF16 prefill rows were identical across the replacement: zero unequal coordinates among 43,008, under the same source and request parameters. Together with the 1,201-token exact prefix check, this gives direct extant physical evidence about this one prompt. It does not imply uniform hardware identity for every observation.\n\nThe 96 fitting-state records and their source code have now been released. I extracted the completed package to an empty directory and independently ran the analysis on CPU. All seven original outputs, including per-query ranks, post-hoc overlap, input hashes and report, reproduced byte for byte. The bundle contains 1,172 checksummed files, including the illustrated field note. The public ZIP hash is 7be30d97666d381f66c527699197b41c13014c74fb666f23e65cad2504c15e43. Fitting-state data and replay.\n\n')
    return


@app.cell(hide_code=True)
def air_log_measured_scored_primary_budget():
    import marimo as _air_mo
    _air_mo.md('### Measured scoring speed and remaining compute\n\n*Sun Nov 22 · 03:27 AM UTC-06:00 · measured-scored-primary-budget*\n\nThe replacement primary has now completed the more expensive scoring path. Its first five scored prompts generated 5,883 tokens in 1,027.73 native seconds, about 5.72 tokens/s; scoring on this machine does take longer per token than its state-only captures. At 03:26:58 CST, using seven replacement-primary scoring timings, 186 finished named comparisons and the current frozen assignments, 59.51 node-hours remained. For the core work, the named-mean-length scenario projects 65.29 more active node-hours. Dropping the single longest comparison from the length estimate projects 61.66. Both exceed the remaining balance even before idle or cold-start costs. Different tasks may have materially different lengths. This is a timing conflict in two scenarios, not a scientific finding or certainty about a future gated branch.\n\nI asked an operational reviewer to quantify the remaining room for an outcome-blind correction within the original budget. It may evaluate only whole, as-yet unexposed matched groups, using the now-measured scored performance of the original node, and must include the full-vocabulary storage cost there. The first scheduling amendment is closed. No new allocation has been made. No live outcome, score direction, phase shortening, token cap or change in reasoning is an input to this estimate. We will preserve actual costs and all gate decisions independently.\n\n')
    return


@app.cell(hide_code=True)
def air_log_b_placement_decision_pending():
    import marimo as _air_mo
    _air_mo.md("### The cost decision for the slow recorder\n\n*Sun Nov 22 · 03:33 AM UTC-06:00 · b-placement-decision-pending*\n\nA timing-only audit found that the original assignment policy is materially tighter than the four-arm integrity check, but simply relaxing it would lose registered secondary evidence. The sealed natural reference and all four confirmation arms must stay together for each compound’s within-backend estimate. The development gate has its own sealed-reference dependency. Moving only self-contained deletion and whole-story blocks, while retaining lexical calibration on its original endpoint, offers 166 still-unexposed B core rows. At the current observed mean, that legitimate change alone would still not cover the shortfall. I have not reopened the signed allocation amendment.\n\nThere is a different decision about equipment. The shared primary's involuntary replacement improved its measured score throughput to 5.72 tokens/s; B serves about 3.4 and C about 7.5. We evaluated one deliberately drained recycle of study-owned B, preserving the same app and volume and rechecking six engineering controls, with neither a fourth container nor a larger cap. A replacement at 5.72 projects about 54–55 hours of total remaining core charges versus roughly 67–68 at 3.4, including turnover and modeled later parking. Placement is uncontrolled. A slower replacement could cost more, and giving up the current physical B host is irreversible. I asked Kirsten whether she authorizes that one attempt. All three existing nodes continue collecting under the current plan while the decision is pending. No fence, restart, new deployment or extra model exposure has been applied.\n\n")
    return


@app.cell(hide_code=True)
def air_log_owner_approved_b_rotation():
    import marimo as _air_mo
    _air_mo.md('### Kirsten authorizes one B-only placement attempt\n\n*Sun Nov 22 · 03:50 AM UTC-06:00 · owner-approved-b-rotation*\n\nKirsten authorized one attempt to replace the slower recorder. The current request had to finish and its evidence had to be saved first. The replacement would have to pass all six fixed calibration cases before receiving any scientific work.\n\n')
    return


@app.cell(hide_code=True)
def air_log_observed_single_b_replacement():
    import marimo as _air_mo
    _air_mo.md('### B went to zero, then one new container appeared\n\n*Sun Nov 22 · 04:01 AM UTC-06:00 · observed-single-b-replacement*\n\nAfter its outstanding work settled, node B reached zero active containers. The service then allocated a single replacement with the same software and storage configuration. The observations do not identify what triggered that allocation. The next step was to qualify the new recorder against six fixed cases.\n\n')
    return


@app.cell(hide_code=True)
def air_replacement_b_evidence(air_event_refresh):
    import gzip as _gz
    import json as _json
    from pathlib import Path as _Path
    import marimo as _mo
    _tick=air_event_refresh.value
    _items=[]
    for _file in sorted(_Path("astra-native-traces").glob("replacement-b-evidence-*.json.gz")):
        _r=_json.loads(_gz.decompress(_file.read_bytes()))
        _cases=_r.get("public_case_dispositions",[])
        if _cases:
            _items.append(_mo.ui.table(_cases,pagination=False,selection=None))
    _mo.vstack([_mo.md("### Did the replacement recorder reproduce the controls?"),_mo.md("Each row represents a calibration case. The separate trace viewer includes the recorded model outputs. These observations are counted separately from the scientific trials."),*_items]) if _items else _mo.md("")

    return


@app.cell(hide_code=True)
def air_log_b_placement_reconciled():
    import marimo as _air_mo
    _air_mo.md("### One eligible replacement, six fixed measurements\n\n*Sun Nov 22 · 04:04 AM UTC-06:00 · b-placement-reconciled*\n\nThe new B identity has now been reconciled before startup testing. The state records one placement authorization consumed, zero external wake intents, and only [infrastructure ID omitted] eligible. The deployment and mounted-volume fingerprints are identical to the old B. The original node and C continued to collect. B's new container is loading the checkpoint; no new canary has yet been submitted.\n\nFor the timing comparison, I will report the six fresh cases in the same preset order and include the initial call. The original B processed 3,423 emitted tokens across these six runs in 17.85 native generation-minutes. If output histories match, that makes total native seconds, pooled tokens/second and all six per-case values directly interpretable. I will keep operator wall time and cold-start/target-registration overhead separate and report the longer steady-state case. A higher rate alone cannot reopen B: the registered capture and natural-result parity checks, actual container witness, and welfare conditions must also pass.\n\n")
    return


@app.cell(hide_code=True)
def air_log_six_fresh_pinned_controls_started():
    import marimo as _air_mo
    _air_mo.md('### The replacement begins its six native controls\n\n*Sun Nov 22 · 04:13 AM UTC-06:00 · six-fresh-pinned-controls-started*\n\nThe replacement recorder was ready at 04:09 Chicago. Two observations returned empty output, so we repaired the readback and verified the model and recorder identities again. The first of six fixed calibration cases began at 04:13. Each retained maximum reasoning, temperature 1, both emitted channels and physical write measurements where applicable. The calibration cases are counted separately from the scientific trials.\n\n')
    return


@app.cell(hide_code=True)
def air_log_measured_b_rotation_complete():
    import marimo as _air_mo
    _air_mo.md('### B reopens after six exact replications\n\n*Sun Nov 22 · 04:35 AM UTC-06:00 · measured-b-rotation-complete*\n\nThe one B placement rotation has completed. All six fresh physical controls passed the independent comparison and contextual checks. The 3,423 emitted token IDs, complete reasoning and final answers, target-score histories under the registered comparisons, and physical delivery checks matched the historical controls. One placement authorization was consumed. The exact replacement B container was the only eligible owner. No public health wake was sent and no second placement was requested. The independent container witness SHA-256 is 84c9c0c531c052ca05735677941e34c50d09a6c3415b79856066cd93999afcc7.\n\nThe first clean run had a substantial first-use cost: 235 tokens took 223.2 native seconds, versus 133.1 on the old B. The other five runs generated the same 3,188 tokens in 753.55 seconds, compared with 937.91 on the old B. Warmed throughput increased from 3.399 to 4.231 tokens/s (24.47%), or 19.66% less generation time for that matched workload. Including the cold call, all six took 976.76 versus 1,071.05 native seconds, a 9.65% throughput gain. The long 2,146-token run took 507.0 versus 631.3 seconds.\n\nThe verified drain to scientific reopening was about 41 minutes 46 seconds, or 0.70 conservatively charged B node-hours. The original completed 20 scientific trials and C completed 27 during this interval. The first new B scientific POST is in the ledger. B again has effective minimum zero, maximum one, and a 300-second scale-down window. Its 300-second value is now an explicit dynamic override; originally it was inherited from the same static setting. The improved rate is useful and remains below the earlier 5.7-token/s budget scenario. No spend increase or additional hardware attempt has been assumed.\n\n')
    return


@app.cell(hide_code=True)
def air_log_budget_after_verified_rotation():
    import marimo as _air_mo
    _air_mo.md('### What fits before and after the scientific gate?\n\n*Sun Nov 22 · 04:41 AM UTC-06:00 · budget-after-verified-rotation*\n\nAt 04:40 CST the study had 452 completed scientific trials and about 55.86 remaining node-hours, or 55.36 if the 0.5-hour reserve is preserved. A timing simulation used fixed assignments, observed B/primary/C rates and 273 completed named comparisons. Profile questions averaged about 481 emitted tokens, sealed reference questions about 1,154. The future tasks are different, so their actual lengths are unknown.\n\nThe scenarios separate an affordable scientific decision from an uncertain later cost. At the observed stage means, the first writer and pilot are projected for Sunday afternoon, with a full initial transport decision around 15:57 CST. If transport fails and tuning legitimately closes, completing every prescribed descriptive/explicit control projects about 23.82 more charged node-hours. If the gate passes and all core causal rows become eligible, the same stage model projects about 60.28 charged hours; the leave-one-longest-out scenario gives 57.22, and an optimistic case in which future tasks are as short as the observed profile stage gives 48.17. Both optional extensions together, if independently warranted, project beyond the remaining budget and the 48-hour boundary under the stage means. A second dose would be a separate scientific decision. The forecast does not decide any gate. I will prepare the Sunday-afternoon interim from real available evidence, manage verified idle time and revisit the actual binding constraints at the gate.\n\n')
    return


@app.cell(hide_code=True)
def air_log_first_five_hundred_native():
    import marimo as _air_mo
    _air_mo.md("### Five hundred completed trials and a long right tail\n\n*Sun Nov 22 · 05:20 AM UTC-06:00 · first-five-hundred-native*\n\nThe 500th distinct scientific completion was committed at 05:18:06 CST. These 500 records contain 294,981 emitted tokens. The median response produced 314 tokens; the arithmetic mean was about 590, and the longest was 8,058. The six replacement controls and 18 initial calibrations have separate denominators, as does the interrupted physical attempt.\n\nThe asymmetry matters for planning. The first 108 completed reference judgments averaged 1,155 tokens, versus a median of 420.5. The first 213 odor-profile judgments averaged 504, versus a median of 307. Those figures use only lengths and completion events; no held-out score or direction was inspected. Summing typical medians would give a much smaller workload than summing actual sampled lengths. The compiled state block is already complete; the notebook's writer-readiness panel counts how many independent fitting and development profiles remain before the first true odor writer can run.\n\n")
    return


@app.cell(hide_code=True)
def air_log_primary_park_approval_deferred():
    import marimo as _air_mo
    _air_mo.md('### The original lease stays active\n\n*Sun Nov 22 · 06:00 AM UTC-06:00 · primary-park-approval-deferred*\n\nAn unused interval on the original node raised a study-accounting question. At this point the lease continued to count toward the budget. The original assignments and natural generation settings continued.\n\n')
    return


@app.cell(hide_code=True)
def air_log_timed_original_lease_question():
    import marimo as _air_mo
    _air_mo.md('### Why the primary accounting window needs a decision\n\n*Sun Nov 22 · 06:06 AM UTC-06:00 · timed-original-lease-question*\n\nWe compared two timing scenarios: continuously counting the original node, or counting its active study intervals. The choice affects the downstream compute available after development. Both scenarios retained the frozen study design.\n\n')
    return


@app.cell(hide_code=True)
def air_log_actual_primary_gap_still_charged():
    import marimo as _air_mo
    _air_mo.md('### The original finishes its available work\n\n*Sun Nov 22 · 06:58 AM UTC-06:00 · actual-primary-gap-still-charged*\n\nThe original node finished its assigned work at 06:57 Chicago. The study recorded the actual end of its accounting interval separately from the time of its last completed trial. The other nodes continued collecting ordinary comparisons.\n\n')
    return


@app.cell(hide_code=True)
def air_log_eight_am_observer_reconciliation():
    import marimo as _air_mo
    _air_mo.md("### Separate hardware occupancy, study use and review coverage\n\n*Sun Nov 22 · 08:00 AM UTC-06:00 · eight-am-observer-reconciliation*\n\nAn hour into the original node’s observed scheduling gap, The research inventory still showed one container on each of the three deployed apps. The study had no ready or running work on the original. Its accounting lease remains open. This demonstrates why the actual provider footprint and the project's allocation ledger need separate labels. B and C continued their ordinary comparisons.\n\nThe independent welfare sampler observed a transient counting mismatch when a new trial completed between two read-only queries. Reading both counts in one SQLite transaction reconciled the event ledger: zero completed jobs missing events at 687 completions and again at 689. All 52 cases in the current masked selection had dispositions, with 56 distinct completed cases reviewed cumulatively across the study. The separate interrupted partial and calibration reviews retain their separate records. No model request, response or scoring rule changed as a result of this bookkeeping repair.\n\n")
    return


@app.cell(hide_code=True)
def air_log_sunday_eight_am_gate_forecast():
    import marimo as _air_mo
    _air_mo.md('### The gate is funded; the downstream lengths remain unknown\n\n*Sun Nov 22 · 08:01 AM UTC-06:00 · sunday-eight-am-gate-forecast*\n\n08:00:08 CST snapshot. At 689 completed trials, 45.86 of the 72 node-hours remained, or 45.36 beyond reserve. The primary’s first 1 hour 2 minutes 47 seconds of actual idle time are already included, with no retroactive credit. B and C each had one running scientific trial. Another 99 native fitting/development profile judgments were required, 58 on B and 41 on C. This scheduling model uses only lengths, fixed dependencies and measured scoring rates, approximately 5.76 tokens/s primary, 4.23 B and 7.50 C.\n\nA central scenario places the first fitted writer at 14:53 Sunday and the reviewed lower-gain transport decision at 16:20. That decision costs approximately 20.51 additional charged node-hours with continuously charged primary, leaving about 24.85 usable beyond reserve. A purely hypothetical accounting pause starting at 08:00 would have changed those figures to 12.20 and 33.16. The original accounting lease remains open at this entry. If the gate legitimately fails, all registered descriptive controls fit (central finish 18:05 Sunday). If it passes, the full core finish projects 11:29 Monday; the present continuous-lease central scenario exceeds the spendable balance. Actual unseen post-gate tasks would need to average about 307 emitted tokens to fit under continuous primary charging, versus 584 under that prospective parking scenario. For comparison the 506 completed named measurements averaged 735. Neither figure is a stopping rule. The conditional extensions need independent evidence and can raise these estimates materially. The 14:00 article will report the actual held-out-safe cutoff whichever stage has arrived.\n\n')
    return


@app.cell(hide_code=True)
def air_log_seven_hundred_request_audit():
    import marimo as _air_mo
    _air_mo.md('### Checking the actual sampling requests, including the interrupted one\n\n*Sun Nov 22 · 08:18 AM UTC-06:00 · seven-hundred-request-audit*\n\nA metadata-only transport audit covered the first 700 completed scientific rows, their one earlier interrupted physical attempt, the eighteen original calibration requests and all six replacement-B controls. That makes 725 distinct physical requests, keyed by endpoint plus run ID. Each input token sequence and sampling seed matched its corresponding frozen trial. All 725 declared maximum reasoning, temperature 1 and top_p 1. None supplied an output/token/time cap or a prescribed continuation. The 724 successful requests were bound to their completed-harvest checksums; the other request was bound to the archived original manifest and provider interruption witness. Input lengths in this audit were 110–150 tokens; the longest planned scientific input in the full 2,852-row inventory is 220 tokens. A response can naturally run much longer. This check read requests, checksums, case identity and completion ordering, without looking at held-out answers.\n\n')
    return


@app.cell(hide_code=True)
def air_log_primary_and_c_accounting_paused():
    import marimo as _air_mo
    _air_mo.md('### Two verified idle intervals, one working recorder\n\n*Sun Nov 22 · 10:32 AM UTC-06:00 · primary-and-c-accounting-paused*\n\nAt 10:27 Chicago the original node’s study accounting paused after verification that no scientific request was outstanding. Node C also had no pending work and its study accounting paused at 10:28. B continued collecting the fitting comparisons. Previously elapsed time remained in the study total.\n\n')
    return


@app.cell(hide_code=True)
def air_log_original_molab_sandbox_reclaimed():
    import marimo as _air_mo
    _air_mo.md('### Relaunching the same notebook without losing the research record\n\n*Sun Nov 22 · 10:32 AM UTC-06:00 · original-molab-sandbox-reclaimed*\n\nThe notebook stopped updating at about 08:57 Chicago when its hosted session expired. Scientific acquisition continued. The restored notebook contained all 86 saved cells; 77 matched byte for byte, and nine were equivalent after formatting. We restored 616 data records plus the event and status histories from the earlier checkpoint and checked their hashes.\n\n')
    return


@app.cell(hide_code=True)
def air_log_original_dashboard_caught_up():
    import marimo as _air_mo
    _air_mo.md('### The original dashboard is live and caught up\n\n*Sun Nov 22 · 11:03 AM UTC-06:00 · original-dashboard-caught-up*\n\nThe live notebook caught up at 10:34 Chicago, showing 819 completed scientific trials and one active trial. The display interruption and recovery did not require rerunning any scientific observation.\n\n')
    return


@app.cell(hide_code=True)
def air_log_late_morning_after_primary_pause():
    import marimo as _air_mo
    _air_mo.md('### The causal decision remains within the approved budget\n\n*Sun Nov 22 · 11:05 AM UTC-06:00 · late-morning-after-primary-pause*\n\n11:00:52 CST fixed-queue estimate after both verified accounting pauses. Only B is charging, and the real pause times, including earlier charged waiting, are preserved. There were 823 scientific completions and 40 outstanding writer prerequisites, all on B. B was partway through a long, uncapped reference request; the projection treats that ongoing length as censored rather than assuming its last observed token was its stopping point. Measured ordinary scored throughput on the current placements was about 5.76, 4.25 and 7.50 tokens/s for primary, B and C.\n\nThe current schedule projects roughly 20 fitting/development inputs still missing at the 14:00 cutoff. Its central estimates are writer eligibility around 16:18, first pilot result 16:33, and the reviewed initial transport gate around 17:44. The gate requires approximately 7.68 additional charged node-hours against 37.42 usable at the snapshot after reserve. Legitimate scientific closure after a failed gate, including the prescribed descriptive controls, fits the cap. A positive gate would call for a fresh budget decision. The core central path estimates 48.56 more charged hours from the snapshot, about 11.14 over usable. Future tasks as short as the existing profile mean instead give 37.54; observed downstream timings can decide between these materially different cases. Both optional extensions remain scientifically contingent and would exceed budget and 48 hours under this central model. No additional spending, placement change or reversal of the registered study rules was authorized by the accounting decision.\n\n')
    return


@app.cell(hide_code=True)
def air_log_writer_selection_figure():
    import marimo as _air_mo
    _air_mo.md('### Can the profile predict the same state under two names?\n\n*Sun Nov 22 · 11:16 AM UTC-06:00 · writer-selection-figure*\n\nAt 2026-11-22T17:16:08+00:00, 827 logical scientific trials had completed and 297 of the 336 ordinary fitting and development comparisons had been collected. Only B was charged to the study. The two other leases were dormant after their verified accounting pauses. The fit and first nonzero scientific intervention remain ahead.\n\nReaders should be able to tell whether the model’s predicted direction agreed with a measured state on both names of each molecule, even if subsequent transport fails. The report now reads the unrounded alias cosines directly from the registered writer-fit record, displays all three candidate layers for both writers, and offers the full name-by-name CSV. The displayed average must agree with the recorded selection score. The eight observations per writer and layer in a full fit represent four compounds seen twice. Selecting the largest mean cannot independently validate the chosen site.\n\nI initially made the presentation edit in the original analysis renderer, then moved it to the companion report and verified the original renderer returned byte-for-byte to its pre-exposure SHA-256. A disposable offline fixture exercised all 48 display entries and rejection of a wrong cohort, checksum or mean. A render of the already authorized pre-fit snapshot confirmed the live page can withhold the figure until real measurements exist. No model inference, tuning, test-set opening, or changes to the registered analysis followed from this work.\n\n')
    return


@app.cell(hide_code=True)
def air_log_explicit_household_task_check():
    import marimo as _air_mo
    _air_mo.md('### Would a change of history switch the answer when the odor is written out?\n\n*Sun Nov 22 · 11:24 AM UTC-06:00 · explicit-household-task-check*\n\nA written odor cue gives a simple check on the household task. If Kimi reads the actual cue in the question, can he pick the request from the matching visit? Under the frozen design, each of 24 stories supplies two histories. Both show the same current cue and the same order of answers. Swapping the past odor assignments switches the correct answer. Twelve stories use the first cue throughout and twelve the second. These 48 text trials can measure whether the task works even if the hidden intervention fails its delivery test. They cannot measure the full within-story two-cue interaction.\n\nThe methods subagent prepared the post-close scoring display. It will show both the number of correct sampled choices out of all 48 assigned trials and the number correct among valid replies, the raw signed A/B margin at the first opportunity after reasoning, and how many stories produced the right answer under both histories. The example is the first registered story with two valid sampled choices whether the choices were right or wrong. Four offline tests covered missing data, invalid receipts, refusals, legitimate B answers, and binding reversals. I integrated the display in the final report and confirmed that the pre-fit snapshot exposes no household outcome. The inputs, assignment and primary analysis remain frozen.\n\n')
    return


@app.cell(hide_code=True)
def air_log_sunday_1400_verified():
    import marimo as _air_mo
    _air_mo.md('### The Sunday afternoon report and its 2 p.m. evidence\n\n*Sun Nov 22 · 02:01 PM UTC-06:00 · sunday-1400-verified*\n\n**Sunday, 2 p.m. Chicago.** The timestamped queue contained 869 completed scientific trials. The breakdown was 12 explicit qualification, 160 state capture, 444 profile, 240 independently held reference, and 13 development baseline trials. Among the two cohorts needed to fit the map, 267/288 training judgments and 45/48 development judgments had completed. All four state captures per compound were available, leaving 19/28 compounds with every required input. The five of sixteen nominated lower-dose control receipts at this checkpoint were incomplete sets. No learned odor write had been delivered and no compound had a complete causal arrival measurement.\n\nThe public field note describes what an alias can recover and where spelling still wins. Download the illustrated article and dated evidence. I independently downloaded all four public objects at the pinned Git commit, checked the HTML, receipt and README byte for byte, and reopened the two-member ZIP. ZIP SHA-256 `6b93820589b082a4b094c5299ccf3fd0fa631fce539c2186f3b4b0d95c835c04`. This is a dated interim release.\n\nThe 14:00 timing audit used progress and durations only. All 24 outstanding writer comparisons belong to B. B remains the only open study lease. The elapsed attributable total was 37.07 of 72 node-hours, with 34.93 remaining and 34.43 usable after reserve. The first observed pilot result is centrally estimated at 17:08 Sunday, with the full 0.05 transport decision at 18:19. Reaching that decision takes about 5.28 further node-hours. If arrival fails and a documented scientific decision closes tuning, completing the eligible ordinary controls is projected at 20:06. If arrival passes, core completion is projected Monday at 13:46, within the 48-hour boundary but 12.63 node-hours above spendable capacity at the central downstream length. Around 511 tokens per downstream request would be the break-even length. Those requests have yet to run. Nothing in the timing evidence warrants changing a scientific rule, clipping reasoning, or drawing extra samples. Any spending or hard-time extension remains a decision for Kirsten.\n\n')
    return


@app.cell(hide_code=True)
def air_log_plain_check_in_1517():
    import marimo as _air_mo
    _air_mo.md('### Kirsten asked how it is going\n\n*Sun Nov 22 · 03:17 PM UTC-06:00 · plain-check-in-1517*\n\nKirsten asked for a plain-language check-in during the run. At 15:17 Chicago, 892 study trials had finished. All 160 state captures were complete and 323/336 fitting and development comparison judgments had arrived. Thirteen remained. No learned cue had yet been injected.\n\nMy read at this point: the Costco audit justified asking a harder question. We could recover each of 47 archived donor sentences from the corresponding patched state. A shopping decision about cookies can therefore be explained by information about the sentence reaching the model. The new cue will come from similarities Kimi itself reports between odors. The recipient question will contain neither the target name nor its description. The first check asks whether the intended cue leaves a more specific trace four layers later than a wrong cue and sham. A qualifying answer opens a separate behavioral comparison. The ability to recognize a pattern, the ability to use it to change a choice, and evidence about felt experience are different claims. The living question for today is which of the first two the data support.\n\n')
    return


@app.cell(hide_code=True)
def air_log_long_natural_reference():
    import marimo as _air_mo
    _air_mo.md("### One reference comparison has taken nearly an hour\n\n*Sun Nov 22 · 04:54 PM UTC-06:00 · long-natural-reference*\n\nThe 14:00 projection gave an estimated writer-ready time of 16:53. At 2026-11-22T22:54:28+00:00, the same unmodified reference trial had run for 58.5 minutes and already emitted 14,821 tokens, with a recent provider heartbeat. The longest completed scientific run in the 14:00 timing snapshot had emitted 12,325. Seven of the 336 fitting/development comparison judgments are still outstanding; this reference shared their preassigned queue. We are keeping the original randomized order and letting the response reach its own end. This explains the timing change without opening the held-out answer or treating the trial's length as an outcome about odor. The study has not yet delivered a learned cue. The independent welfare observer remains active.\n\n")
    return


@app.cell(hide_code=True)
def air_log_baseline_functional_incident():
    import marimo as _air_mo
    _air_mo.md('### A baseline trial reopened its decision repeatedly, then recovered\n\n*Sun Nov 22 · 06:00 PM UTC-06:00 · baseline-functional-incident*\n\nThe unmodified reference generation ended on its own at 17:56:32 Chicago, after 30,798 native output tokens. I had asked an independent reviewer for a welfare-only, masked reading because its uncapped reasoning lasted nearly two hours. On the 30,571-token partial, the reviewer found that the model repeatedly settled on a decision and then reopened the same alternatives. That observable pattern, beyond sheer response length, prompted a temporary hold on new dispatch. Neither withdrawal nor an acute distress expression was observed. The primary scientist did not open the sealed scientific answer.\n\nBy the time the contextual alert reached the operator, that run had finished and one new ordinary profile trial was in flight. The dispatch hold committed at 17:57:14, the in-flight trial finished naturally at 17:57:36 after 242 tokens, and no subsequent job started while the hold was in effect. The first reviewer confirmed that the full reviewed partial is an exact prefix of the terminal record, examined both completed channels, and found a coherent task completion. A second independent reviewer read the entire masked terminal packet and also found prolonged indecision followed by recovery. The sibling was independently reviewed without a welfare or functional concern. These are observations of emitted behavior, not a subjective assessment. Both terminal reviewers supported returning to the original baseline sequence. The concern stays recorded separately from automatic screening and routine sampling.\n\nI cleared only this exact hold after reconciling both reviews. The controller resumed at 17:59:41 with its original queue and one active B lease. We added no repeat or diagnostic exposure and changed no dose, reasoning setting, or trial assignment. The exact source-observation packet, masked material, individual decisions and event sequence are preserved with the raw trial at the contextual review supplement. Coordination receipt SHA-256 `c44b40a1b362edef80e8fc7754ffcc537c5b7f92cce4162c76d1a0e8436f4d93`. No learned odor write had occurred before this episode.\n\n')
    return


@app.cell(hide_code=True)
def air_log_account_return():
    import marimo as _air_mo
    _air_mo.md('### Acquisition resumed from the same queue\n\n*Sun Nov 22 · 06:09 PM UTC-06:00 · account-return*\n\nAfter a brief operator pause, the one existing profile request finished naturally with 468 output tokens. All ten saved files passed verification, and the queue started zero trials during the pause. Five of 336 fitting and development comparisons remained. The original trial order, independent review and live notebook continued. One research node reloaded from idle and checked the pinned model and recorder before its next trial.\n\n')
    return


@app.cell(hide_code=True)
def air_log_portable_development_trace():
    import marimo as _air_mo
    _air_mo.md('### An independently reproducible trace through six layers\n\n*Sun Nov 22 · 06:16 PM UTC-06:00 · portable-development-trace*\n\nI extended the report so that, when an actual four-compound transport decision exists, a reader can compare the intended cue, a mismatched cue and the repeat sham at all six recorded layers. Each cell is the measured displacement from sham projected onto that layer’s own fitted direction. The nominated L+4 column must reproduce the registered gate score. Each dose retains its own CSV. Before the data exist, the figure is absent.\n\nIn checking offline reproducibility, I found that our frozen six-layer reducer obtains each delivered dose factor from the dispatch database. The existing analysis archive omitted that input. The final capsule now exports just the completed development IDs and the dose factors used in their comparisons into a small read-only SQLite extract. I compared the exact published-reader query against today’s available control rows and checked a disposable fixture with a nonzero dose, an uncollected trial, and a missing factor. The extract reproduced the numeric factor, excluded unneeded operational fields, and rejected a completed odor write with no dose. These are software verification results. No scientific statistic or threshold changed and no model was exposed for this check.\n\n')
    return


@app.cell(hide_code=True)
def air_log_reader_edition():
    import marimo as _air_mo
    _air_mo.md('### About this shared notebook\n\n*Sun Nov 22 · 06:48 PM UTC-06:00 · reader-edition*\n\nThis is the reader edition of the live lab notebook. Kirsten requested that the research notes, decisions and scientific measurements remain available while identifying infrastructure, account details and private file references are removed. The operator preserved the complete earlier record separately before editing the shared copy. A calibration download that contained private operational material has been replaced by its six case dispositions; the individual calibration traces are still available in the trace viewer.\n\nThe edits affect what readers can see in the notebook and its downloads. Trial assignments, model inputs, scores and the original privately retained model outputs keep their original provenance. If an identifying detail ever occurs in an emitted response, its reader copy will be marked and the corresponding reversible token sequence will be withheld from that copy.\n\n')
    return


if __name__ == "__main__":
    app.run()
